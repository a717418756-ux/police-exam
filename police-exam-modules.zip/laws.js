// ══ laws.js — 資料庫（法條）管理 ══════════════════════════════
// 依賴：db.js, utils.js, parser.js

// 法規排序狀態

function toggleLawSort(){
  _lawSortBy = _lawSortBy==='name' ? 'date' : 'name';
  toast(_lawSortBy==='date'?'依修正日期排序':'依名稱排序');
  renderDB();
}

async function renderDB(){  try{
  const ls=await da('laws');
  const kw=(document.getElementById('lsi')?.value||'').toLowerCase().trim();
  let fl=ls.filter(l=>{
    if(S.lawCat!=='all'&&l.category!==S.lawCat)return false;
    if(kw){
      const h=((l.lawName||'')+(l.article||'')+(l.content||'')+(l.keywords||[]).join(' ')).toLowerCase();
      if(!h.includes(kw))return false;
    }
    return true;
  });
  const byName={};
  fl.forEach(l=>{const n=l.lawName||'未分類';if(!byName[n])byName[n]=[];byName[n].push(l);});
  const el=document.getElementById('llist');
  if(!fl.length){el.innerHTML='<div class="empty"><span class="ic">🗄</span><span>尚無資料</span></div>';return;}
  // 排序
  const sortedEntries=Object.entries(byName).sort((a,b)=>{
    const sortBy=S.lawSort||'name';
    if(sortBy==='amend'){
      // 發布修正日期排序：最新在前
      // 支援「民國113年1月1日」和「2024-01-01」兩種格式
      const toDate=s=>{
        if(!s)return '';
        // 民國年轉西元
        const rocM=s.match(/民國(\d+)年(\d+)月(\d+)日/);
        if(rocM)return String(parseInt(rocM[1])+1911)+'-'+rocM[2].padStart(2,'0')+'-'+rocM[3].padStart(2,'0');
        return s; // 已是西元或其他格式
      };
      const da=toDate(a[1][0]?.amendDate)||'0000';
      const db=toDate(b[1][0]?.amendDate)||'0000';
      return db.localeCompare(da); // 最新在前
    }
    if(sortBy==='count') return b[1].length-a[1].length; // 條數多在前
    return a[0].localeCompare(b[0],'zh-TW'); // 名稱 A-Z
  });
  // 用 data-name 避免法規名稱含特殊字元導致 onclick 失效
  el.innerHTML=sortedEntries.map(([name,laws])=>{
    const cat=laws[0].category||'statute';
    const catLabel={'statute':'法規條文','sop':'SOP','supplement':'補充資料','interpretation':'函釋'}[cat]||cat;
    const favCount=laws.filter(l=>l.favorite).length;
    const icon=cat==='sop'?'📋':cat==='supplement'?'📄':'⚖';
    const orgLine=(laws[0]?.org||laws[0]?.amendDate)
      ?('<div style="font-size:10px;color:var(--t2);margin-top:1px">'
        +(laws[0]?.org?'🏛 '+esc(laws[0].org):'')
        +(laws[0]?.org&&laws[0]?.amendDate?' · ':'')
        +(laws[0]?.amendDate?'📅 '+esc(laws[0].amendDate):'')
        +'</div>')
      :'';
    return '<div class="lw-card card" data-lawname="'+esc(name)+'" style="margin-bottom:6px;cursor:pointer">'
      +'<div style="display:flex;align-items:center;gap:8px">'
        +'<span style="font-size:20px">'+icon+'</span>'
        +'<div style="flex:1">'
          +'<div style="font-size:15px;font-weight:700;color:var(--t0)">'+esc(name)+'</div>'
          +'<div style="font-size:11px;color:var(--t2);margin-top:2px">'+catLabel+' · '+laws.length+' 條'+(favCount?' · ⭐'+favCount:'')+'</div>'
          +orgLine
        +'</div>'
        +'<span style="color:var(--t2);font-size:18px">›</span>'
        +'<button class="lw-del" data-lawname="'+esc(name)+'" style="background:var(--red2);color:var(--red);border:1px solid var(--red);border-radius:6px;padding:4px 8px;font-size:12px;cursor:pointer;flex-shrink:0">🗑</button>'
      +'</div>'
    +'</div>';
  }).join('');
  // 綁定 click 事件（避免 onclick 字串引號問題）
  el.querySelectorAll('.lw-card').forEach(card=>{
    card.addEventListener('click',function(e){
      if(e.target.classList.contains('lw-del'))return;
      openLawGroup(this.dataset.lawname);
    });
  });
  el.querySelectorAll('.lw-del').forEach(btn=>{
    btn.addEventListener('click',function(e){
      e.stopPropagation();
      delLawGroup(this.dataset.lawname);
    });
  });
  }catch(e){ logError('renderDB',e); }}
function renderLaws(){ return renderDB(); }

function setLC(el,cat){
  document.querySelectorAll('#lchips .chip').forEach(c=>c.classList.remove('on'));
  el.classList.add('on');S.lawCat=cat;renderDB();
}
function setLSort(el,sort){
  document.querySelectorAll('#l-sort-name,#l-sort-amend,#l-sort-count').forEach(c=>c&&c.classList.remove('on'));
  el.classList.add('on');S.lawSort=sort;renderDB();
}

async function openLawGroup(lawName){  try{
  const allLaws=await da('laws');
  const laws=allLaws.filter(l=>l.lawName===lawName)
    .sort((a,b)=>(a.articleNumber||0)-(b.articleNumber||0));
  if(!laws.length)return;
  const others=[...new Set(allLaws.map(l=>l.lawName).filter(Boolean))].filter(n=>n!==lawName).slice(0,8);
  const cat=laws[0].category||'statute';
  const icon=cat==='sop'?'📋':cat==='supplement'?'📄':'⚖';
  document.getElementById('lv-name').textContent=icon+' '+lawName;
  // 顯示法規機關/日期資訊
  const lvInfo=document.getElementById('lv-info');
  if(lvInfo){
    const s=laws[0]||{};
    lvInfo.textContent=(s.org?'🏛 '+s.org:'')+(s.org&&s.amendDate?' · ':'')+(s.amendDate?'📅 '+s.amendDate:'');
    lvInfo.style.display=(s.org||s.amendDate)?'block':'none';
  }
  const sb=document.getElementById('lv-star');
  const favN=laws.filter(l=>l.favorite).length;
  sb.textContent=favN?'★':'☆';
  sb.style.color=favN?'var(--org)':'var(--t2)';
  sb.onclick=async()=>{
    const nf=laws.filter(l=>l.favorite).length>0;
    for(const l of laws){l.favorite=!nf;await dp('laws',l);}
    openLawGroup(lawName);
  };
  const jumpHtml=others.map(n=>'<button class="chip" style="flex-shrink:0;font-size:11px" onclick="openLawGroup(\''+esc(n)+'\')">'+esc(n)+'</button>').join('');

  // 按章分組
  const byChapter={};
  laws.forEach(l=>{const ch=l.chapter||'';if(!byChapter[ch])byChapter[ch]=[];byChapter[ch].push(l);});

  let arts='';
  Object.entries(byChapter).forEach(([ch,cls])=>{
    if(ch) arts+='<div id="ch-'+encodeURIComponent(ch)+'" style="font-size:12px;font-weight:700;color:var(--pur);padding:6px 12px 4px;margin-top:8px;border-left:3px solid var(--pur)">'+esc(ch)+'</div>';
    cls.forEach(l=>{
      const isImg=l.content&&l.content.startsWith('data:image');
      const contentHtml=isImg?'<img src="'+l.content+'" style="max-width:100%;border-radius:8px">':br(l.content||'');
      const kwHtml=(l.keywords||[]).length?'<div style="margin-top:8px">'+l.keywords.map(k=>'<span class="tag">'+esc(k)+'</span>').join('')+'</div>':'';
      const relHtml=(l.relatedLaws||[]).length
        ?'<div style="margin-top:9px;font-size:11px;color:var(--t2)">🔗 關聯法條：</div>'
          +l.relatedLaws.map(r=>'<button class="chip" style="font-size:11px;margin:2px" onclick="showLawPop(\''+esc(r.ref||r.lawName||'')+'\')" >⚖ '+esc(r.ref||r.lawName||'')+'</button>').join('')
        :'';
      arts+='<div style="margin-bottom:12px;padding:12px;background:var(--bg2);border-radius:8px;border-left:3px solid var(--pur2)">'
        +'<div style="font-size:14px;font-weight:700;color:var(--pur);margin-bottom:6px;display:flex;align-items:center;justify-content:space-between">'
          +'<span>'+esc(l.article||'')+(l.title?' — '+esc(l.title):'')+'</span>'
          +'<div style="display:flex;gap:6px">'
            +'<button onclick="editLawInView('+l.id+')" style="background:none;border:none;color:var(--t2);font-size:12px;cursor:pointer">✏</button>'
            +'<button onclick="delLaw('+l.id+')" style="background:none;border:none;color:var(--red);font-size:12px;cursor:pointer">🗑</button>'
          +'</div>'
        +'</div>'
        +'<div style="font-size:14px;line-height:1.85;color:var(--t1)">'+contentHtml+'</div>'
        +kwHtml+relHtml
      +'</div>';
    });
  });

  // 章節列表（用於快速分配）
  const chapterSet=new Set(laws.map(l=>l.chapter||'').filter(Boolean));
  const chapterList=[...chapterSet];
    // 章節管理按鈕
  const chMgrBtn='<button onclick="openChapterMgr(window.currentLawName)" style="background:none;border:1px solid var(--bd);border-radius:6px;padding:2px 8px;font-size:11px;cursor:pointer;color:var(--t2);margin-left:4px">⚙ 管理章節</button>';
  const chMgrBtnNew='<div style="margin-bottom:6px"><button onclick="openChapterMgr(window.currentLawName)" style="background:none;border:1px solid var(--bd);border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;color:var(--t2)">⚙ 新增章節分類</button></div>';
  const chTagsHtml=chapterList.map(ch=>'<span class="tag" style="color:var(--pur);cursor:pointer" onclick="scrollToChapter(this,\''+encodeURIComponent(ch)+'\')" title="點擊跳轉">'+esc(ch)+'</span>').join('');
  const chapterMgmtHtml=chapterList.length
    ?'<div style="margin-bottom:8px"><div style="font-size:11px;color:var(--t2);margin-bottom:4px">章節：'+chTagsHtml+chMgrBtn+'</div></div>'
    :chMgrBtnNew;

  document.getElementById('lbody').innerHTML=
    '<div style="padding:4px 0 10px">'
    +(others.length?'<div class="sec" style="padding:0 0 4px;font-size:11px">快速跳轉</div><div style="overflow-x:auto;display:flex;gap:6px;padding:6px 0">'+jumpHtml+'</div>':'')
    +'<div class="sec" style="padding:8px 0 6px;font-size:11px">'+esc(lawName)+' · '+laws.length+' 條</div>'
    +chapterMgmtHtml
    +arts
    +'</div>';
  window.currentLawName=lawName;window.currentLawContent=laws.map(l=>l.article+' '+l.content).join('\n');
  S.curLawName=lawName; // 供編輯按鈕使用
  document.getElementById('lv').style.display='flex';
  }catch(e){ logError('openLawGroup',e); }}

function exitLaw(){ document.getElementById('lv').style.display='none'; }
async function addLawInGroup(){
  try{
    const lawName=S.curLawName||window.currentLawName;
    if(!lawName){toast('請先開啟一個法規');return;}
    showAddLaw({lawName, article:'', category:'statute',
      content:'', keywords:[], relatedLaws:[], title:''});
  }catch(e){logError('addLawInGroup',e);}
}

async function editLawGroupInfo(){  try{
  const lawName=(S.curLawName||window.currentLawName||'').trim();
  if(!lawName){toast('請先開啟法規');return;}
  const allLaws=await da('laws');
  const sample=allLaws.find(l=>l.lawName===lawName)||{};
  const newOrg=prompt('制定機關（如：行政院、內政部）：',sample.org||'');
  if(newOrg===null)return;
  const rawAmend=prompt('發布／修正日期（格式：YYYMMDD，如 1130509 = 民國113年05月09日）：',sample.amendDate||'');
  if(rawAmend===null)return;
  // 解析 YYYMMDD 格式
  const parsedAmend=parseMinguoDate(rawAmend.trim());
  const targets=allLaws.filter(l=>l.lawName===lawName);
  for(const l of targets){
    l.org=newOrg.trim();
    l.amendDate=parsedAmend;
    await dp('laws',l);
  }
  toast('法規資訊已更新（共'+targets.length+'條）✓');
  openLawGroup(lawName);
  }catch(e){ logError('editLawGroupInfo',e); }}

// 解析民國日期：1130509 → 民國113年05月09日
function parseMinguoDate(s){
  if(!s)return '';
  // 已是完整格式
  if(/民國\d+年/.test(s))return s;
  // YYYMMDD 格式（7位）
  const m7=s.match(/^(\d{3})(\d{2})(\d{2})$/);
  if(m7)return '民國'+m7[1]+'年'+m7[2]+'月'+m7[3]+'日';
  // YYYYMMDD 西元（8位）
  const m8=s.match(/^(\d{4})(\d{2})(\d{2})$/);
  if(m8)return '民國'+(parseInt(m8[1])-1911)+'年'+m8[2]+'月'+m8[3]+'日';
  // 其他格式原樣儲存
  return s;
}

async function editCurLaw(){  try{
  // 功能：快速新增條文到目前法規（預填法規名稱）
  const lawName=(S.curLawName||window.currentLawName||'').trim();
  if(!lawName){toast('請先開啟一個法規');return;}
  // 取得目前法規的類別，預填到新增 sheet
  const allLaws=await da('laws');
  const sample=allLaws.find(l=>l.lawName===lawName);
  showAddLaw({
    lawName:lawName,
    article:'',
    category:sample?.category||'statute',
    content:'',keywords:[],relatedLaws:[],
    org:sample?.org||'',
    amendDate:sample?.amendDate||''
  });
  }catch(e){ logError('editCurLaw',e); }}
async function editLawInView(id){  try{ const l=await dg('laws',id);if(l)showAddLaw(l);   }catch(e){ logError('editLawInView',e); }}
async function toggleLawFav(id){  try{ const l=await dg('laws',id);if(!l)return;l.favorite=!l.favorite;await dp('laws',l);renderDB();toast(l.favorite?'已收藏':'已取消收藏');   }catch(e){ logError('toggleLawFav',e); }}
function toggleLawStar(){}

async function startLawCloze(){
  startClozeLaw(window.currentLawContent, window.currentLawName);
}
async function quizFromLaw(){  try{
  const lawName=(S.curLawName||window.currentLawName||'').trim();
  if(!lawName){toast('請先開啟一個法規');return;}
  const qs=await da('questions');
  if(!qs.length){toast('題庫尚無題目');return;}

  // 精確比對：refName 必須完全等於 lawName（去掉條號後）
  const pool=qs.filter(q=>{
    const rels=q.relatedLaws||[];
    if(!rels.length) return false;
    return rels.some(r=>{
      const ref=(r.ref||r.lawName||'').trim();
      if(!ref) return false;
      // 取 ref 的法規名稱部分（去掉條號 §X 或 第X條）
      const refName=ref.replace(/§.*/,'').replace(/第?\d+條.*/,'').trim();
      // 只有完全相等才算匹配，避免「警察法」誤匹配「警察法施行細則」
      return refName===lawName;
    });
  });

  if(!pool.length){
    toast('無關聯題目。請在題目「關聯法條」欄填入「'+lawName+'」後重試');
    return;
  }
  exitLaw();
  setTimeout(()=>startQWithPool(pool,'📚 '+lawName), 50);
  }catch(e){ logError('quizFromLaw',e); }}

async function delLawGroup(lawName){  try{
  const all=await da('laws');
  const targets=all.filter(l=>l.lawName===lawName);
  if(!targets.length){toast('找不到對應法條');return;}
  if(!confirm('確定刪除「'+lawName+'」全部 '+targets.length+' 條？無法復原。'))return;
  for(const l of targets) await dd('laws',l.id);
  toast('已刪除「'+lawName+'」共 '+targets.length+' 條');
  renderDB();
  }catch(e){ logError('delLawGroup',e); }}

async function delLaw(id){  try{
  if(!confirm('確定刪除此條文？'))return;
  await dd('laws',id);
  toast('已刪除');
  renderDB();
  }catch(e){ logError('delLaw',e); }}

async function showAddLaw(l){
  try{
  S.editLawId=l?.id||null;
  document.getElementById('law-sh-t').textContent=l?'編輯法條':'新增法條';
  document.getElementById('l-name').value=l?.lawName||'';
  document.getElementById('l-art').value=l?.article||'';
  const chEl=document.getElementById('l-chapter');
  if(chEl)chEl.value=l?.chapter||'';
  if(document.getElementById('l-note'))document.getElementById('l-note').value=l?.note||'';
  const tiEl=document.getElementById('l-title');
  if(tiEl)tiEl.value=l?.title||'';
  document.getElementById('l-cat').value=l?.category||'statute';
  document.getElementById('l-content').value=(l?.content&&!l.content.startsWith('data:image'))?l.content:'';
  document.getElementById('l-kw').value=(l?.keywords||[]).join(',');
  const relEl=document.getElementById('l-related');
  if(relEl)relEl.value=(l?.relatedLaws||[]).map(r=>r.ref||'').filter(Boolean).join(',');
  const srcEl=document.getElementById('l-src');
  if(srcEl)srcEl.value=l?.source||'';
  window._sopImgData=(l?.content?.startsWith('data:image'))?l.content:null;
  const prev=document.getElementById('l-img-prev');
  if(prev)prev.innerHTML=window._sopImgData?'<img src="'+window._sopImgData+'" style="max-width:100%;border-radius:8px">':'';
  toggleSOPMode();
  // 更新制定機關 datalist
  da('laws').then(all=>{
    const orgs=[...new Set(all.map(l=>l.org).filter(Boolean))];
    const dl=document.getElementById('l-org-list');
    if(dl)dl.innerHTML=orgs.map(o=>'<option value="'+esc(o)+'">').join('');
  });
  document.getElementById('law-ov').classList.add('on');
  }catch(e){logError('showAddLaw',e);}
}

function closeLawSh(){ document.getElementById('law-ov').classList.remove('on');S.editLawId=null; }

function switchLawMode(mode){
  const cw=document.getElementById('l-content-wrap');
  const iw=document.getElementById('l-img-wrap');
  if(mode==='img'){
    if(cw)cw.classList.add('hide');
    if(iw)iw.classList.remove('hide');
  } else {
    if(cw)cw.classList.remove('hide');
    if(iw)iw.classList.add('hide');
  }
}

function toggleSOPMode(){
  const cat=document.getElementById('l-cat')?.value;
  const cw=document.getElementById('l-content-wrap');
  const iw=document.getElementById('l-img-wrap');
  const tw=document.getElementById('l-img-toggle-wrap');
  const hasImg=window._sopImgData!=null;

  if(cat==='sop'){
    // SOP：預設圖片模式
    if(cw)cw.classList.add('hide');
    if(iw)iw.classList.remove('hide');
    if(tw)tw.style.display='none';
  } else if(cat==='supplement'||cat==='interpretation'){
    // 補充資料/函釋：可選文字或圖片，預設文字（有圖片資料則預設圖片）
    if(tw)tw.style.display='block';
    if(hasImg){
      if(cw)cw.classList.add('hide');
      if(iw)iw.classList.remove('hide');
    } else {
      if(cw)cw.classList.remove('hide');
      if(iw)iw.classList.add('hide');
    }
  } else {
    // 法規條文：只有文字
    if(cw)cw.classList.remove('hide');
    if(iw)iw.classList.add('hide');
    if(tw)tw.style.display='none';
  }
}

// 切換圖片/文字模式（補充資料/函釋用）
function onLawImgSelect(e){ loadSOPImg(e); }
function loadSOPImg(e){
  const file=e.target.files[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=ev=>{
    window._sopImgData=ev.target.result;
    const prev=document.getElementById('l-img-prev');
    if(prev)prev.innerHTML='<img src="'+ev.target.result+'" style="max-width:100%;border-radius:8px;margin-top:4px">';
  };
  reader.readAsDataURL(file);
}

async function saveLaw(){
  const cat_=document.getElementById('l-cat').value;
  let content='';
  // sop / supplement / interpretation 都可選擇圖片或文字
  const canUseImg=(cat_==='sop'||cat_==='supplement'||cat_==='interpretation');
  if(canUseImg && window._sopImgData){
    // 有上傳圖片，直接用圖片
    content=window._sopImgData;
  } else {
    content=document.getElementById('l-content').value.trim();
    if(!content){toast('請填寫內容，或上傳圖片');return;}
  }
  const article=document.getElementById('l-art').value.trim();
  const chapter=document.getElementById('l-chapter')?.value.trim()||'';
  const relStr=(document.getElementById('l-related')?.value||'').trim();
  const relatedLaws=relStr?relStr.split(/[,，]/).map(s=>({ref:s.trim()})).filter(r=>r.ref):[];
  const articleNumber=art2n(article)||0;
  const data={
    lawName:document.getElementById('l-name').value.trim(),
    article,chapter,articleNumber,
    category:cat_,
    title:document.getElementById('l-title')?.value.trim()||'',
    content,
    keywords:kwArr(document.getElementById('l-kw').value),
    relatedLaws,
    source:document.getElementById('l-src')?.value.trim()||'',
    org:document.getElementById('l-org')?.value?.trim()||'',
    amendDate:document.getElementById('l-amend')?.value?.trim()||'',
    note:document.getElementById('l-note')?.value.trim()||'',
    favorite:false,createdAt:Date.now()
  };
  if(!data.lawName){toast('請填寫法律名稱');return;}
  if(S.editLawId){
    const ex=await dg('laws',S.editLawId);
    data.id=S.editLawId;
    data.favorite=ex?.favorite||false;
    data.createdAt=ex?.createdAt||Date.now();
  }
  try{
    await dp('laws',data);
    // 更新制定機關 datalist
    if(data.org){
      const dl=document.getElementById('l-org-list');
      if(dl){
        const existing=[...dl.querySelectorAll('option')].map(o=>o.value);
        if(!existing.includes(data.org)){
          const opt=document.createElement('option');
          opt.value=data.org; dl.appendChild(opt);
        }
      }
    }
    closeLawSh();
    toast(S.editLawId?'法條已更新 ✓':'法條已儲存 ✓');
  }catch(e){
    logError('saveLaw',e);
    toast('儲存失敗，請重試');
  }
  renderDB();
}

function showBulkLaw(){ document.getElementById('blaw-ov').classList.add('on'); }
function closeBulkLaw(){ document.getElementById('blaw-ov').classList.remove('on'); }

async function prevBulkLaw(){
  try{
  const text=document.getElementById('bl-text').value;
  const name=document.getElementById('bl-name').value.trim()||'未命名';
  const cat=document.getElementById('bl-cat').value;
  const src=document.getElementById('bl-src').value.trim();
  const items=parseLawText(text,name,cat,src);
  document.getElementById('bl-prev').textContent='預覽：共 '+items.length+' 條（'+items.slice(0,3).map(i=>i.article).join('、')+(items.length>3?'…':'')+'）';
  }catch(e){logError('prevBulkLaw',e);}
}

async function importBulkLaw(){  try{
  const text=document.getElementById('bl-text').value;
  if(!text.trim()){toast('請貼入法條文字');return;}
  const name=document.getElementById('bl-name').value.trim()||'未命名';
  const cat=document.getElementById('bl-cat').value;
  const src=document.getElementById('bl-src').value.trim();
  const items=parseLawText(text,name,cat,src);
  if(!items.length){toast('解析結果為0條，請確認格式（需有「第X條」）');return;}
  await bulkPut('laws',items);
  toast('已匯入 '+items.length+' 條法條 ✓');
  closeBulkLaw();
  renderDB();
  }catch(e){ logError('importBulkLaw',e); }}

async function showLawPop(ref){  try{
  if(!ref)return;
  const laws=await da('laws');
  const artM=ref.match(/第?(\d+)條?/);
  const artNum=artM?parseInt(artM[1]):null;
  const namePart=ref.replace(/第?\d+條?/,'').replace(/§\d+/,'').trim();

  // 只有法規名稱、沒有條號 → 直接跳到法規頁面
  if(artNum===null&&namePart){
    // 找資料庫裡最接近的法規名稱
    const allNames=[...new Set(laws.map(l=>l.lawName).filter(Boolean))];
    const exact=allNames.find(n=>n===namePart||namePart===n);
    const partial=allNames.find(n=>n.includes(namePart)||namePart.includes(n));
    const fuzzy=allNames.find(n=>{
      const cs=namePart.replace(/[法條例規則]/g,'').split('');
      return cs.length>=2&&cs.every(c=>n.includes(c));
    });
    const target=exact||partial||fuzzy;
    if(target){ openLawGroup(target); return; }
    // 找不到也跳頁面（讓 openLawGroup 顯示空狀態）
    openLawGroup(namePart); return;
  }
  let matched=laws.filter(l=>{
    const ln=l.lawName||'';
    let nm=!namePart||ln.includes(namePart)||namePart.includes(ln);
    if(!nm){
      const cs=namePart.replace(/[法條例規則]/g,'').split('');
      if(cs.length>=2)nm=cs.every(c=>ln.includes(c));
    }
    if(!nm)return false;
    return artNum===null||l.articleNumber===artNum;
  });
  if(matched.length>1){const ex=matched.filter(l=>(l.lawName||'').includes(namePart));if(ex.length)matched=ex;}
  const el=document.getElementById('lawpop-ov');if(!el)return;
  if(!matched.length){
    document.getElementById('lawpop-title').textContent=ref;
    document.getElementById('lawpop-body').innerHTML='<span style="color:var(--t2)">查無「'+esc(ref)+'」，請先在資料庫新增。</span>';
    document.getElementById('lawpop-related').innerHTML='';
    el.style.display='flex';return;
  }
  const l=matched[0];
  const isImg=l.content&&l.content.startsWith('data:image');
  document.getElementById('lawpop-title').textContent=(l.lawName||'')+' '+(l.article||'');
  document.getElementById('lawpop-body').innerHTML=isImg?'<img src="'+l.content+'" style="max-width:100%;border-radius:8px">':br(l.content||'');
  const rl=(l.relatedLaws||[]).map(r=>'<button class="chip" style="font-size:11px" onclick="showLawPop(\''+esc(r.ref||r.lawName||'')+'\')" >⚖ '+esc(r.ref||r.lawName||'')+'</button>').join('');
  document.getElementById('lawpop-related').innerHTML=rl?'<div style="margin-top:8px;font-size:12px;color:var(--t2)">關聯法條：</div><div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:3px">'+rl+'</div>':'';
  el.style.display='flex';
  }catch(e){ logError('showLawPop',e); }}
function closeLawPop(){ document.getElementById('lawpop-ov').style.display='none'; }
function autoDetectLawLinks(){}

// ── Shims ──
function openLawPopupByRef(ref){ showLawPop(ref); }
function showQLaws(){ toast('請在編輯題目中查看關聯法條'); }


function scrollToChapter(tagEl, encodedCh){
  const el=document.getElementById('ch-'+encodedCh);
  if(el){
    el.scrollIntoView({behavior:'smooth',block:'start'});
    // 短暫高亮
    el.style.background='var(--pur2)';
    setTimeout(()=>{el.style.background='';},800);
  }
}

async function openChapterMgr(lawName){  try{
  const allLaws=await da('laws');
  const targets=allLaws.filter(l=>l.lawName===lawName).sort((a,b)=>(a.articleNumber||0)-(b.articleNumber||0));
  if(!targets.length){toast('找不到法規');return;}
  const chapters=[...new Set(targets.map(l=>l.chapter||'').filter(Boolean))];
  const chInput=prompt('【章節快速分配】目前章別：'+(chapters.join('、')||'無')+'\n請輸入新章別名稱（如「第一章 總則」），留空取消：');
  if(!chInput||!chInput.trim())return;
  const newCh=chInput.trim();
  const rangeInput=prompt('套用範圍（格式：1-5 代表第1到5條）\n留空則套用到所有未設章別的條文：');
  let startArt=0,endArt=99999;
  if(rangeInput&&rangeInput.trim()){
    const rm=rangeInput.match(/(\d+)\s*[-~]\s*(\d+)/);
    if(rm){startArt=parseInt(rm[1]);endArt=parseInt(rm[2]);}
    else{const n=parseInt(rangeInput);if(!isNaN(n)){startArt=n;endArt=n;}}
  }
  let count=0;
  for(const l of targets){
    const artN=l.articleNumber||0;
    const apply=rangeInput&&rangeInput.trim()?(artN>=startArt&&artN<=endArt):(!l.chapter);
    if(apply){l.chapter=newCh;await dp('laws',l);count++;}
  }
  toast('已套用「'+newCh+'」到 '+count+' 條');
  openLawGroup(lawName);
  }catch(e){ logError('openChapterMgr',e); }}

// ══ questions.js — 題目管理 ════════════════════════════════
// 依賴：db.js, utils.js

let _dupResolve=null;

async function renderHome(){  try{
  const [qs,ats]=await Promise.all([da('questions'),da('attempts')]);
  const now=Date.now();
  const todayStr=today();

  // 統計
  document.getElementById('hs-q').textContent=qs.length;
  document.getElementById('hs-l').textContent=(await da('laws')).length;
  document.getElementById('hs-t').textContent=ats.filter(a=>a.date===todayStr).length;

  // 錯題數
  const ws=getWrong(qs,ats);
  document.getElementById('hs-w').textContent=ws.size;

  // 今日任務
  const reviewDue=qs.filter(q=>(q.nextReview||0)<=now&&q.reviewLevel!==undefined).length;
  const newQ=qs.filter(q=>q.reviewLevel===undefined||q.reviewLevel===null).length;
  const dangerQ=qs.filter(q=>getDangerLevel(q,ats)==='🔴').length;
  const avgTime=ats.length?Math.round(ats.reduce((s,a)=>s+(a.responseTime||0),0)/ats.length/1000):0;
  const estMin=Math.ceil((reviewDue*avgTime||reviewDue*45)/60);

  document.getElementById('h-date').textContent=new Date().toLocaleDateString('zh-TW',{weekday:'long',month:'long',day:'numeric'});
  document.getElementById('h-plan').innerHTML=
    `<span style="color:var(--org)">📅 待複習 ${reviewDue} 題</span> &nbsp;`+
    `<span style="color:var(--red)">🔴 危險 ${dangerQ} 題</span> &nbsp;`+
    `<span style="color:var(--acc)">🆕 新題 ${Math.min(newQ,10)} 題</span> &nbsp;`+
    (estMin?`<span style="color:var(--t2)">⏱ 預估 ${estMin} 分鐘</span>`:'');

  // 最近新增
  const recent=[...qs].sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).slice(0,4);
  document.getElementById('h-recent').innerHTML=recent.map(q=>{
    const danger=getDangerLevel(q,ats);
    return `<div class="qc" onclick="showAdd(q)" style="cursor:pointer">
      <div class="qch">
        <span class="badge ${q.type==='mc'?'bmc':'bes'}">${q.type==='mc'?'選擇':'申論'}</span>
        <span class="tag">${esc(q.subject||'未分類')}</span>
        <span>${danger}</span>
      </div>
      <div class="qst">${esc((q.stem||'').slice(0,60))}…</div>
    </div>`;
  }).join('');

  // datalist 科目
  const subs=[...new Set(qs.map(q=>q.subject).filter(Boolean))];
  ['bi-subs','f-subs'].forEach(id=>{
    const el=document.getElementById(id);
    if(el)el.innerHTML=subs.map(s=>`<option value="${esc(s)}">`).join('');
  });

  // 設定頁資訊
  const expEl=document.getElementById('exp-info');
  if(expEl)expEl.textContent=`題目 ${qs.length} 筆・法條 ${(await da('laws')).length} 筆・作答 ${ats.length} 筆`;
  }catch(e){ logError('renderHome',e); }}

async function renderList(){  try{
  const [qs,ats]=await Promise.all([da('questions'),da('attempts')]);
  const kw=(document.getElementById('si')?.value||'').toLowerCase().trim();
  const f=S.filter||'all';
  const sf=S.subF||'all';
  const ws=getWrong(qs,ats);

  let fl=qs.filter(q=>{
    if(f==='mc'&&q.type!=='mc')return false;
    if(f==='es'&&q.type!=='es')return false;
    if(f==='wrong'&&!ws.has(q.id))return false;
    if(f==='star'&&!q.starred)return false;
    if(sf!=='all'&&q.subject!==sf)return false;
    if(kw){const h=(q.searchBlob||(q.stem||'')+(q.subject||'')+(q.keywords||[]).join(' ')).toLowerCase();if(!h.includes(kw))return false;}
    return true;
  }).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));

  document.getElementById('lc').textContent=`共 ${fl.length} 題`;

  // 科目 chips
  const subs=[...new Set(qs.map(q=>q.subject).filter(Boolean))].sort();
  const schips=document.getElementById('schips');
  if(schips)schips.innerHTML=
    `<button class="chip ${sf==='all'?'on':''}" onclick="setSF(this,'all')">全部科目</button>`+
    subs.map(s=>`<button class="chip ${sf===s?'on':''}" onclick="setSF(this,'${esc(s)}')">${esc(s)}</button>`).join('');

  // 效能：超過200題加提示，避免一次渲染過多 DOM
  const PAGE=200;
  const showAll=fl.length<=PAGE;
  const display=showAll?fl:fl.slice(0,PAGE);
  if(!showAll){
    const info=document.getElementById('lc');
    if(info)info.textContent+=`（顯示前${PAGE}筆，共${fl.length}筆）`;
  }
  document.getElementById('qlist').innerHTML=display.map(q=>{
    const danger=getDangerLevel(q,ats);
    const lvLabel=['🆕','1️⃣','3️⃣','1️⃣','2️⃣','1️⃣','2️⃣'][q.reviewLevel]||'';
    return `<div class="qc ${ws.has(q.id)?'wrong':''} ${q.starred?'star':''}">
      <div class="qch">
        <span class="badge ${q.type==='mc'?'bmc':'bes'}">${q.type==='mc'?'選擇':'申論'}</span>
        <span class="tag">${esc(q.subject||'未分類')}</span>
        ${q.year?`<span class="tag">${esc(q.year)}</span>`:''}
        <span style="font-size:13px">${danger}</span>
        ${q.reviewLevel!==undefined?`<span class="tag" style="color:var(--acc)">Lv${q.reviewLevel}</span>`:''}
      </div>
      <div class="qst">${esc((q.stem||'').slice(0,80))}</div>
      <div class="qa">
        <button class="qabn" onclick="editQ(${q.id})">✏ 編輯</button>
        <button class="qabn" onclick="toggleStar(${q.id})">${q.starred?'★':'☆'}</button>
        <button class="qabn" data-qid="${q.id}" onclick="startSingleQ(this)">▶ 練習</button>
        <button class="qabn" style="color:var(--red)" onclick="delQ(${q.id})">🗑</button>
      </div>
    </div>`;
  }).join('');
  }catch(e){ logError('renderList',e); }}

function setF(el,f){
  document.querySelectorAll('#fchips .chip').forEach(c=>c.classList.remove('on'));
  el.classList.add('on');S.filter=f;renderList();
}
function setSF(el,f){
  document.querySelectorAll('#schips .chip').forEach(c=>c.classList.remove('on'));
  el.classList.add('on');S.subF=f;renderList();
}

function showAdd(q){
  const data=q&&q.id?q:null;
  S.editId=data?.id||null;
  document.getElementById('add-title').textContent=data?'編輯題目':'新增題目';
  setQT(data?.type||'mc');
  document.getElementById('f-sub').value=data?.subject||'';
  document.getElementById('f-yr').value=data?.year||'';
  document.getElementById('f-ex').value=data?.exam||'';
  document.getElementById('f-num').value=data?.num||'';
  document.getElementById('f-stem').value=data?.stem||'';
  document.getElementById('f-kw').value=(data?.keywords||[]).join(',');
  document.getElementById('f-note').value=data?.note||'';
  const isNumEl=document.getElementById('f-is-number');
  if(isNumEl) isNumEl.checked=data?.isNumberQ||false;
  document.getElementById('f-laws').value=(data?.relatedLaws||[]).map(l=>l.ref||l.lawName||'').filter(Boolean).join(',');
  // 申論題關鍵字
  const mustEl=document.getElementById('f-must-kw');
  if(mustEl)mustEl.value=(data?.mustKeywords||[]).join(',');
  buildOpts(data||{});
  document.getElementById('add-ov').classList.add('on');
  setTimeout(()=>document.getElementById('f-stem').focus(),300);
}
function closeAdd(){document.getElementById('add-ov').classList.remove('on');S.editId=null;}

function setQT(t){
  S.qType=t;
  document.getElementById('tmc').className='btn '+(t==='mc'?'bp':'bg');
  document.getElementById('tes').className='btn '+(t==='es'?'bp':'bg');
  document.getElementById('mc-opts').classList.toggle('hide',t!=='mc');
  document.getElementById('es-area').classList.toggle('hide',t!=='es');
  // (10) 申論必寫關鍵字只在申論題顯示
  const mustWrap=document.getElementById('must-kw-wrap');
  if(mustWrap) mustWrap.classList.toggle('hide',t!=='es');
}

function buildOpts(q){
  const opts=q.options||{A:'',B:'',C:'',D:''};
  const ans=(q.answer||'').replace(/[, ]/g,'');
  // 初始化多選集合
  S.correctSet=new Set(ans.split('').filter(c=>/[A-E]/.test(c)));
  S.correct=ans;
  document.getElementById('opts-c').innerHTML=
    ['A','B','C','D','E'].map(k=>`
      <div class="oi">
        <button class="cb ${ans===k?'sel':''}" id="cb-${k}" onclick="setCorr('${k}')">${k}</button>
        <input id="opt-${k}" placeholder="選項 ${k}" value="${esc(opts[k]||'')}">
      </div>`).join('');
  document.getElementById('f-es').value=q.answerEs||'';
}

function setCorr(k){
  // 支援多選：再次點擊已選的取消，多個選項可同時選
  if(!S.correctSet) S.correctSet=new Set();
  if(S.correctSet.has(k)) S.correctSet.delete(k);
  else S.correctSet.add(k);
  // 排序後合併成答案字串
  S.correct=[...S.correctSet].sort().join('');
  ['A','B','C','D','E'].forEach(c=>{
    const el=document.getElementById('cb-'+c);
    if(el)el.className='cb'+(S.correctSet.has(c)?' sel':'');
  });
}

const _debouncedRenderList=debounce(renderList,200);

async function saveQ(){
  try{
  const stem=cleanSpaces(document.getElementById('f-stem').value.trim());
  if(!stem){toast('請填寫題目內容');return;}
  const type=S.qType;
  const options={};
  if(type==='mc'){
    ['A','B','C','D','E'].forEach(k=>{
      const v=cleanSpaces(document.getElementById('opt-'+k)?.value.trim()||'');
      if(v)options[k]=v;
    });
    if(Object.keys(options).length<2){toast('選擇題至少需要2個選項');return;}
  }
  const relStr=document.getElementById('f-laws')?.value.trim()||'';
  const relatedLaws=relStr?relStr.split(/[,，]/).map(s=>({ref:s.trim()})).filter(r=>r.ref):[];
  const mustStr=document.getElementById('f-must-kw')?.value.trim()||'';
  const mustKeywords=mustStr?mustStr.split(/[,，]/).map(s=>s.trim()).filter(Boolean):autoKeywords(stem);

  const data={
    type,stem,options,
    answer:type==='mc'?S.correct:'',
    answerEs:document.getElementById('f-es')?.value.trim()||'',
    subject:document.getElementById('f-sub').value.trim(),
    year:document.getElementById('f-yr').value.trim(),
    exam:document.getElementById('f-ex').value,
    num:document.getElementById('f-num').value.trim(),
    keywords:kwArr(document.getElementById('f-kw').value),
    mustKeywords,
    tags:[],
    note:document.getElementById('f-note').value.trim(),
    isNumberQ:document.getElementById('f-is-number')?.checked||false,
    relatedLaws,
    starred:false,createdAt:Date.now(),
    reviewLevel:0,nextReview:Date.now(),lastReview:null,
    wrongCount:0,correctStreak:0,difficultyScore:5
  };

  if(!S.editId){
    const dup=await checkDuplicate(data);
    if(dup){
      const action=await showDupDialog(data,dup);
      if(action==='skip'){closeAdd();return;}
      if(action==='replace'){data.id=dup.id;data.starred=dup.starred;data.createdAt=dup.createdAt;data.reviewLevel=dup.reviewLevel||0;}
    }
  } else {
    const ex=await dg('questions',S.editId);
    data.id=S.editId;
    data.starred=ex?.starred||false;
    data.createdAt=ex?.createdAt||Date.now();
    data.reviewLevel=ex?.reviewLevel||0;
    data.nextReview=ex?.nextReview||Date.now();
    data.wrongCount=ex?.wrongCount||0;
    data.correctStreak=ex?.correctStreak||0;
    data.difficultyScore=ex?.difficultyScore||5;
  }
  try{
    // 建立搜尋索引（加速搜尋）
    data.searchBlob=((data.stem||'')+' '+(data.subject||'')+' '+(data.keywords||[]).join(' ')).toLowerCase();
    await dp('questions',data);
    closeAdd();toast(S.editId?'題目已更新 ✓':'題目已儲存 ✓');
  }catch(e){
    logError('saveQ',e);
    toast('儲存失敗，請重試');
  }
  if(S.page==='list')renderList();else renderHome();
  }catch(e){logError('saveQ',e);}}

async function editQ(id){  try{const q=await dg('questions',id);if(q)showAdd(q);  }catch(e){ logError('editQ',e); }}
async function toggleStar(id){  try{
  const q=await dg('questions',id);if(!q)return;
  q.starred=!q.starred;await dp('questions',q);
  toast(q.starred?'已收藏 ⭐':'取消收藏');renderList();
  }catch(e){ logError('toggleStar',e); }}
async function delQ(id){  try{
  if(!confirm('確定刪除此題目？'))return;
  await dd('questions',id);toast('已刪除');renderList();
  }catch(e){ logError('delQ',e); }}

async function checkDuplicate(data){  try{
  const qs=await da('questions');
  const stem30=(data.stem||'').slice(0,30);
  return qs.find(q=>
    q.id!==data.id&&(
      (q.subject===data.subject&&q.year===data.year&&q.num&&data.num&&q.num===data.num)||
      ((q.stem||'').slice(0,30)===stem30&&stem30.length>5)
    )
  )||null;
  }catch(e){ logError('checkDuplicate',e); }}

function showDupDialog(newData,existing){
  return new Promise(res=>{
    _dupResolve=res;
    const diff='【現有題目】\n'+( existing.stem||'').slice(0,60)+'…\n\n【新題目】\n'+(newData.stem||'').slice(0,60)+'…';
    document.getElementById('dup-diff').textContent=diff;
    document.getElementById('dup-ov').style.display='flex';
  });
}
function dupAction(action){
  document.getElementById('dup-ov').style.display='none';
  if(_dupResolve){_dupResolve(action);_dupResolve=null;}
}

async function startSingleQ(el){  try{
  const qid=parseInt(el.dataset.qid);
  const q=await dg('questions',qid);
  if(!q){toast('找不到題目');return;}
  startQWithPool([q],'single');
  }catch(e){ logError('startSingleQ',e); }}

function formatYearInput(el){
  let v=(el.value||'').trim();
  if(!v)return;
  // 純數字1-3位 → 民國XXX年
  if(/^\d{1,3}$/.test(v)){
    el.value='民國'+v+'年';
  }
  // 已是民國格式，不動
}

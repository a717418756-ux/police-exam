// ══ settings.js — 設定與匯出 ══════════════════════════
// 依賴：db.js, utils.js

async function renderSet(){  try{
  const[qs,ats,ls]=await Promise.all([da('questions'),da('attempts'),da('laws')]);
  document.getElementById('exp-info').textContent=`${qs.length} 題 · ${ls.length} 條法條 · ${ats.length} 筆作答`;
  const subs=[...new Set(qs.map(q=>q.subject).filter(Boolean))];
  document.getElementById('db-info').innerHTML=`總題數：${qs.length}<br>法條數：${ls.length}<br>作答記錄：${ats.length}<br>科目：${subs.join('、')||'無'}<br>題型：選擇 ${qs.filter(q=>q.type==='mc').length} / 申論 ${qs.filter(q=>q.type==='es').length}`;

  }catch(e){ logError('renderSet',e); }}
async function expJSON(){  try{
  const[qs,ats,ls]=await Promise.all([da('questions'),da('attempts'),da('laws')]);
  dl(JSON.stringify({version:2,exportedAt:new Date().toISOString(),questions:qs,laws:ls,attempts:ats},null,2),'警察考題庫_'+today()+'.json','application/json');
  toast('已匯出 JSON');
  }catch(e){ logError('expJSON',e); }}

async function impJSON(e){
  const file=e.target.files[0];if(!file)return;
  try{
    const raw=await file.text();
    let data;
    try{ data=JSON.parse(raw); }catch(pe){ toast('JSON 格式錯誤，無法解析');return; }
    // 格式驗證
    if(typeof data!=='object'||data===null){ toast('匯入失敗：格式不正確');return; }
    const qs=Array.isArray(data)?data:(Array.isArray(data.questions)?data.questions:null);
    if(!qs){ toast('匯入失敗：找不到題目資料（questions 欄位）');return; }
    if(qs.length===0){ toast('匯入的題目數量為 0');return; }
    // 抽查第一筆格式
    const sample=qs[0];
    if(typeof sample!=='object'||!sample.stem){ toast('匯入失敗：題目格式不正確（缺少 stem 欄位）');return; }
    // 版本提示
    if(data.version&&data.version>3){ toast('⚠ 此備份版本較新，部分欄位可能不相容'); }
    let n=0;
    for(const q of qs){const{id,...r}=q;await dp('questions',r);n++;}
    if(Array.isArray(data.laws))for(const l of data.laws){const{id,...r}=l;await dp('laws',r);}
    if(Array.isArray(data.attempts))for(const a of data.attempts){const{id,...r}=a;await dp('attempts',r);}
    toast('已匯入 '+n+' 題 ✓');e.target.value='';renderSet();
  }catch(err){ logError('impJSON',err); toast('匯入失敗：'+err.message); }
}

async function expWrong(){  try{
  const[qs,ats]=await Promise.all([da('questions'),da('attempts')]);
  const wids=getWrong(qs,ats);const wqs=qs.filter(q=>wids.has(q.id));
  if(!wqs.length){toast('目前沒有錯題');return;}
  dl(buildHTML(wqs,'錯題整理'),'警察考題_錯題_'+today()+'.html','text/html');toast(`匯出 ${wqs.length} 題`);
  }catch(e){ logError('expWrong',e); }}

async function expAll(){  try{
  const qs=await da('questions');if(!qs.length){toast('題庫是空的');return;}
  dl(buildHTML(qs,'警察考題庫'),'警察考題庫_'+today()+'.html','text/html');toast(`匯出 ${qs.length} 題`);
  }catch(e){ logError('expAll',e); }}

function buildHTML(qs,title){
  const grp={};qs.forEach(q=>{const s=q.subject||'未分類';if(!grp[s])grp[s]=[];grp[s].push(q);});
  const d=new Date().toLocaleDateString('zh-TW');
  let out='<!DOCTYPE html><html lang="zh-TW"><head><meta charset="UTF-8"><title>'+title+'</title><style>body{font-family:sans-serif;max-width:800px;margin:0 auto;padding:24px;line-height:1.8;color:#111}h1{font-size:22px;border-bottom:2px solid #333;padding-bottom:7px}h2{font-size:17px;color:#1f6feb;margin-top:28px}.q{margin:14px 0;padding:14px;border:1px solid #ddd;border-radius:8px}.qn{font-size:11px;color:#666}.qs{font-size:14px;font-weight:600;margin-bottom:8px}.opt{font-size:13px;margin:3px 0}.ans{margin-top:8px;font-size:12px;color:#1f6feb;font-weight:600}.note{font-size:11px;color:#666}</style></head><body><h1>'+title+' — '+d+'</h1>';
  Object.entries(grp).forEach(([sub,sqs])=>{
    out+='<h2>'+sub+'</h2>';
    sqs.forEach((q,i)=>{
      const meta=[q.year,q.exam,q.num?'第'+q.num+'題':''].filter(Boolean).join(' · ');
      out+='<div class="q"><div class="qn">'+meta+' · '+(q.type==='mc'?'選擇題':'申論題')+'</div><div class="qs">'+(i+1)+'. '+(q.stem||'')+'</div>';
      if(q.type==='mc')Object.entries(q.options||{}).forEach(([k,v])=>{out+='<div class="opt">('+k+') '+v+'</div>';});
      if(q.answer)out+='<div class="ans">答案：'+q.answer+'</div>';
      if(q.answerEs)out+='<div class="note">解析：'+q.answerEs+'</div>';
      if(q.note)out+='<div class="note">備註：'+q.note+'</div>';
      out+='</div>';
    });
  });
  return out+'</body></html>';
}


async function clearAts(){  try{
  await dc('attempts');
  toast('作答記錄已清除');
  renderSet();
  }catch(e){ logError('clearAts',e); }}

async function delAll(){  try{
  await dc('questions');
  await dc('attempts');
  await dc('laws');
  toast('已全部刪除');
  renderSet();
  }catch(e){ logError('delAll',e); }}


// ── 圖示設定 ─────────────────────────────────────────────────
const DEFAULT_ICONS = {
  home:'🏠', list:'📝', db:'⚖', stats:'📊', bulk:'📋',
  star:'⭐', wrong:'❌', review:'📅', exam:'📝', quick:'⚡',
  number:'🔢', groups:'🧩', addQ:'➕', addLaw:'⚖',
  quiz:'🎯', correct:'✓', incorrect:'✗',
};

function loadIconSettings(){
  try {
    const saved=localStorage.getItem('examIcons');
    return saved ? {...DEFAULT_ICONS,...JSON.parse(saved)} : {...DEFAULT_ICONS};
  } catch(e){ return {...DEFAULT_ICONS}; }
}

function saveIconSettings(){
  const icons={};
  const inputs=document.querySelectorAll('#icon-editor input[data-icon-key]');
  inputs.forEach(inp=>{
    const key=inp.getAttribute('data-icon-key');
    const val=inp.value.trim();
    if(val) icons[key]=val;
  });
  localStorage.setItem('examIcons',JSON.stringify(icons));
  toast('圖示設定已儲存 ✓');
  applyIconSettings();
}

function resetIconSettings(){
  localStorage.removeItem('examIcons');
  renderIconEditor();
  applyIconSettings();
  toast('已恢復預設圖示');
}

function applyIconSettings(){
  const icons=loadIconSettings();
  // 更新導覽列圖示（依 data-icon 屬性）
  document.querySelectorAll('[data-icon]').forEach(el=>{
    const key=el.getAttribute('data-icon');
    if(icons[key]) el.textContent=icons[key];
  });
}

function renderIconEditor(){
  const el=document.getElementById('icon-editor');
  if(!el)return;
  const icons=loadIconSettings();
  const labels={
    home:'首頁',list:'題目列表',db:'資料庫',stats:'統計',bulk:'大量匯入',
    star:'收藏',wrong:'錯題',review:'複習',exam:'模擬考',quick:'快刷',
    number:'數字魔鬼',groups:'概念群組',addQ:'新增題目',addLaw:'新增法條',
    quiz:'出題',correct:'答對',incorrect:'答錯',
  };
  el.innerHTML=Object.entries(DEFAULT_ICONS).map(([key,def])=>`
    <div style="display:flex;align-items:center;gap:6px;background:var(--bg2);padding:7px 10px;border-radius:8px">
      <span style="font-size:12px;color:var(--t2);flex:1">${esc(labels[key]||key)}</span>
      <input data-icon-key="${key}" value="${esc(icons[key]||def)}"
        style="width:42px;text-align:center;font-size:18px;background:var(--bg3);border:1px solid var(--bd);border-radius:6px;padding:3px">
    </div>`).join('');
}


// ── 圖示自訂系統 ──────────────────────────────────────────────
// 用 localStorage 儲存自訂圖示
const ICON_KEYS={
  'nav-home':'首頁','nav-list':'題目','nav-db':'資料庫',
  'nav-stats':'統計','nav-set':'設定','nav-bulk':'匯入',
  'nav-groups':'群組',
  'badge-mc':'選擇題','badge-es':'申論題',
  'home-review':'今日複習','home-wrong':'危險題',
  'home-quick':'快刷','home-exam':'模擬考',
  'home-all':'隨機刷題','home-number':'數字魔鬼',
  'home-star':'收藏題目','home-browse':'題目閱覽','home-groups':'概念群組',
};

function _loadIcons(){
  try{ return JSON.parse(localStorage.getItem('customIcons')||'{}'); }catch(e){return {};}
}
function _saveIcons(icons){
  try{ localStorage.setItem('customIcons',JSON.stringify(icons)); }catch(e){}
}
function getIcon(key, def){
  const icons=_loadIcons();
  return icons[key]||def;
}

function openIconEditor(){
  const ov=document.getElementById('icon-ov');
  if(ov){ov.classList.add('on');renderIconList();}
}
function closeIconEditor(){
  const ov=document.getElementById('icon-ov');
  if(ov)ov.classList.remove('on');
}
function renderIconList(){
  const el=document.getElementById('icon-list');
  if(!el)return;
  const icons=_loadIcons();
  el.innerHTML=Object.entries(ICON_KEYS).map(([key,label])=>{
    const cur=icons[key]||'';
    return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:8px;background:var(--bg2);border-radius:8px">'
      +'<span style="flex:1;font-size:13px;color:var(--t1)">'+esc(label)+'</span>'
      +'<button data-ikey="'+esc(key)+'" onclick="editIconByEl(this)" style="font-size:22px;background:var(--bg3);border:1px solid var(--bd);border-radius:8px;padding:4px 10px;cursor:pointer;min-width:50px">'+(cur||'✏')+'</button>'
      +(cur?'<button data-ikey="'+esc(key)+'" onclick="resetIconByEl(this)" style="background:none;border:none;color:var(--t2);font-size:11px;cursor:pointer;padding:2px 4px">重置</button>':'')
    +'</div>';
  }).join('');
}
function renderIconSettings(){
  const el=document.getElementById('icon-settings');
  if(!el)return;
  const icons=_loadIcons();
  el.innerHTML='<div style="font-size:13px;color:var(--t2);margin-bottom:8px">點擊圖示可修改（輸入 emoji）</div>'
    +Object.entries(ICON_KEYS).map(([key,label])=>{
      const cur=icons[key]||'';
      return '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;padding:6px 8px;background:var(--bg2);border-radius:8px">'
        +'<span style="width:60px;font-size:11px;color:var(--t2)">'+esc(label)+'</span>'
        +'<button data-ikey="'+esc(key)+'" onclick="editIconByEl(this)" style="font-size:20px;background:none;border:1px solid var(--bd);border-radius:6px;padding:2px 8px;cursor:pointer">'+(cur||'✏')+'</button>'
        +(cur?'<button data-ikey="'+esc(key)+'" onclick="resetIconByEl(this)" style="background:none;border:none;color:var(--t2);font-size:11px;cursor:pointer">重置</button>':'')
      +'</div>';
    }).join('')
    +'<button class="btn bg bw" style="padding:8px;font-size:12px;margin-top:4px" onclick="resetAllIcons()">全部重置</button>';
}
function editIconByEl(btn){editIcon(btn.dataset.ikey);}
function resetIconByEl(btn){resetIcon(btn.dataset.ikey);}

function editIcon(key){
  const icons=_loadIcons();
  const cur=icons[key]||'';
  const nv=prompt('輸入新圖示（emoji）：',cur);
  if(nv===null)return;
  if(nv.trim()) icons[key]=nv.trim();
  else delete icons[key];
  _saveIcons(icons);
  toast('圖示已更新，重新整理頁面生效');
}
function resetIcon(key){
  const icons=_loadIcons();
  delete icons[key];
  _saveIcons(icons);
}
function resetAllIcons(){
  if(!confirm('確定重置所有圖示？'))return;
  localStorage.removeItem('customIcons');
  toast('已重置，重新整理頁面生效');
}


// (3) 套用自訂圖示到 DOM（在 init 後呼叫）
function applyCustomIcons(){
  const icons=_loadIcons();
  if(!Object.keys(icons).length)return;
  // 1. nav 按鈕（底部五個）
  document.querySelectorAll('.nb').forEach(btn=>{
    const page=btn.getAttribute('onclick')?.match(/goPage\('(\w+)'/)?.[1];
    if(!page)return;
    const key='nav-'+page;
    if(icons[key]){
      const ic=btn.querySelector('.ic');
      if(ic)ic.textContent=icons[key];
    }
  });
  // 2. 首頁快捷按鈕（.qb）
  const homeKeyMap={
    '今日複習':'home-review','危險題':'home-wrong','快刷5題':'home-quick',
    '模擬考':'home-exam','隨機刷題':'home-all','數字魔鬼':'home-number',
    '收藏題目':'home-star','題目閱覽':'home-browse','概念群組':'home-groups'
  };
  document.querySelectorAll('.qb').forEach(btn=>{
    const txt=btn.textContent.trim();
    const matched=Object.keys(homeKeyMap).find(k=>txt.includes(k));
    if(!matched)return;
    const key=homeKeyMap[matched];
    if(icons[key]){
      const ic=btn.querySelector('.ic');
      if(ic)ic.textContent=icons[key];
      else btn.textContent=icons[key]+' '+txt.replace(/^.+\s/,'');
    }
  });
  // 3. badge（選擇/申論）
  if(icons['badge-mc']){
    document.querySelectorAll('.badge.bmc').forEach(el=>{el.textContent=icons['badge-mc'];});
  }
  if(icons['badge-es']){
    document.querySelectorAll('.badge.bes').forEach(el=>{el.textContent=icons['badge-es'];});
  }
}

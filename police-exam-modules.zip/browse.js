// ══ browse.js — 題目閱覽 + 主題群組 ═══════════════════════
// 依賴：db.js, utils.js

let _browseQs=[];

async function openBrowse(){  try{
  window._brType=window._brType||'all';
  _browseQs=await da('questions');
  const subs=[...new Set(_browseQs.map(q=>q.subject).filter(Boolean))].sort();
  const chEl=document.getElementById('br-chips');
  if(chEl) chEl.innerHTML=
    '<button class="chip on" onclick="setBrFilter(this,\'all\')">全部科目</button>'+
    subs.map(s=>'<button class="chip" onclick="setBrFilter(this,\''+esc(s)+'\')">'+esc(s)+'</button>').join('');
  const years=[...new Set(_browseQs.map(q=>q.year).filter(Boolean))].sort().reverse();
  const yrEl=document.getElementById('br-year-chips');
  if(yrEl) yrEl.innerHTML=
    '<button class="chip on" onclick="setBrYear(this,\'\')">全部年度</button>'+
    years.map(y=>'<button class="chip" onclick="setBrYear(this,\''+esc(y)+'\')">'+esc(y)+'</button>').join('');
  window._brFilter='all'; window._brYear='';
  const kwEl=document.getElementById('br-search');
  if(kwEl) kwEl.value='';
  browseSearch();
  document.getElementById('browse-ov').style.display='flex';
  }catch(e){ logError('openBrowse',e); }}

function closeBrowse(){ document.getElementById('browse-ov').style.display='none'; }

function setBrFilter(el,v){
  document.querySelectorAll('#br-chips .chip').forEach(c=>c.classList.remove('on'));
  el.classList.add('on'); window._brFilter=v; browseSearch();
}
function setBrYear(el,v){
  document.querySelectorAll('#br-year-chips .chip').forEach(c=>c.classList.remove('on'));
  el.classList.add('on'); window._brYear=v; browseSearch();
}
function setBrType(el, typeFilter){
  document.querySelectorAll('#br-type-all,#br-type-mc,#br-type-es').forEach(b=>{if(b)b.classList.remove('on');});
  el.classList.add('on');
  window._brType=typeFilter;
  renderBrowseList();
}

function browseSearch(){ renderBrowseList(); }
const _debouncedBrowseSearch=debounce(browseSearch,200);

function renderBrowseList(){
  const kw=(document.getElementById('br-search')?.value||'').toLowerCase().trim();
  const f=window._brFilter||'all';
  const yr=window._brYear||'';
  const typeF=window._brType||'all';
  let fl=_browseQs.filter(q=>{
    if(typeF!=='all'&&q.type!==typeF) return false;
    if(f!=='all'&&q.subject!==f) return false;
    if(yr&&q.year!==yr) return false;
    if(kw){
      const h=((q.stem||'')+(q.subject||'')+(q.year||'')+(q.keywords||[]).join(' ')+(q.tags||[]).join(' ')).toLowerCase();
      if(!h.includes(kw)) return false;
    }
    return true;
  }).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0));

  const el=document.getElementById('br-list');
  if(!el) return;
  if(!fl.length){
    el.innerHTML='<div class="empty"><span class="ic">🔍</span><span>沒有符合的題目</span></div>';
    return;
  }
  el.innerHTML=fl.map(q=>{
    const rl=(q.relatedLaws||[]).map(l=>
      '<span class="tag" style="color:var(--pur);cursor:pointer" onclick="showLawPop(\''+esc(l.ref||l.lawName||'')+'\')">⚖ '+esc(l.ref||l.lawName||'')+'</span>'
    ).join('');
    const opts=q.type==='mc'?Object.entries(q.options||{}).map(([k,v])=>
      '<div style="font-size:12px;color:var(--t2);padding:1px 0">('+k+') '+esc(v)+'</div>'
    ).join(''):'';
    return '<div class="card" style="margin:5px 12px">'
      +'<div style="display:flex;align-items:center;gap:5px;margin-bottom:6px;flex-wrap:wrap">'
        +'<span class="badge '+(q.type==='mc'?'bmc':'bes')+'">'+(q.type==='mc'?'選擇':'申論')+'</span>'
        +'<span class="tag">'+esc(q.subject||'未分類')+'</span>'
        +(q.year?'<span class="tag">'+esc(q.year)+'</span>':'')
        +(q.exam?'<span class="tag">'+esc(q.exam)+'</span>':'')
        +(q.num?'<span class="tag">第'+esc(q.num)+'題</span>':'')
        +(q.starred?'<span style="color:var(--org)">⭐</span>':'')
        +(q.reviewLevel!==undefined?'<span class="tag" style="color:var(--acc)">Lv'+q.reviewLevel+'</span>':'')
      +'</div>'
      +'<div style="font-size:14px;line-height:1.65;color:var(--t1);margin-bottom:6px;word-break:break-all">'+esc(q.stem||'')+'</div>'
      +opts
      +(q.answer?'<div style="font-size:12px;color:var(--grn);margin-top:4px;font-weight:600">答案：'+esc(q.answer)+'</div>':'')
      +(q.answerEs?'<div style="font-size:12px;color:var(--t2);margin-top:3px">解析：'+esc(q.answerEs).slice(0,80)+'…</div>':'')
      +(rl?'<div style="margin-top:6px">'+rl+'</div>':'')
    +'</div>';
  }).join('');
}


// ── 概念群組預設資料 ────────────────────────────────────────
const DEFAULT_CONCEPT_GROUPS=[
  {name:'臨檢群組',icon:'🔍',keywords:['臨檢','身分查證','查證身分','公共場所','合法進入','管制站'],laws:['警職法§6','警職法§7','警職法§8'],desc:'警察職權行使法臨檢相關規定'},
  {name:'比例原則',icon:'⚖',keywords:['比例原則','適當性','必要性','相當性','過度禁止'],laws:['警職法§3','警察法§2'],desc:'比例原則三子原則及適用'},
  {name:'即時強制',icon:'⚡',keywords:['即時強制','管束','扣留','使用警械','驅離'],laws:['警職法§19','警職法§20','警械條例§4'],desc:'即時強制類型及要件'},
  {name:'集會遊行',icon:'📢',keywords:['集會','遊行','申請許可','不許可','解散'],laws:['集遊法§8','集遊法§11','集遊法§26'],desc:'集會遊行法重點規定'},
  {name:'警察勤務',icon:'📋',keywords:['勤區查察','巡邏','臨檢','守望','值班','備勤'],laws:['警勤條例§9','警勤條例§11'],desc:'警察六大勤務方式'},
  {name:'社維法',icon:'🏘',keywords:['妨害安寧秩序','妨害善良風俗','妨害公務','罰鍰','申誡'],laws:['社維法§63','社維法§67','社維法§85'],desc:'社會秩序維護法重點條文'},
];
// ── 群組資料讀寫（localStorage）──────────────────────────────
function _loadGroups(){
  try{
    const stored=localStorage.getItem('conceptGroups');
    if(stored){
      const parsed=JSON.parse(stored);
      if(Array.isArray(parsed)&&parsed.length>0) return parsed;
    }
  }catch(e){}
  return DEFAULT_CONCEPT_GROUPS.map(g=>({...g}));
}
function _saveGroups(groups){
  try{ localStorage.setItem('conceptGroups',JSON.stringify(groups)); }catch(e){}
}


async function loadConceptGroups(){  try{
  const saved=await da('conceptGroups');
  if(saved.length) return saved;
  // 首次使用，寫入預設群組
  for(const g of DEFAULT_CONCEPT_GROUPS) await dp('conceptGroups',g);
  return await da('conceptGroups');
  }catch(e){ logError('loadConceptGroups',e); }}

async function saveConceptGroup(g){  try{
  await dp('conceptGroups',g);
  }catch(e){ logError('saveConceptGroup',e); }}

async function deleteConceptGroup(id){  try{
  await dd('conceptGroups',id);
  }catch(e){ logError('deleteConceptGroup',e); }}


async function openConceptGroup(groupId){  try{
  const groups=_loadGroups();
  const group=groups.find(g=>g.id===groupId)||groups[groupId];
  if(!group)return;
  const qs=await da('questions');
  const pool=qs.filter(q=>{
    const text=(q.stem||'')+Object.values(q.options||{}).join('')+(q.keywords||[]).join('');
    return (group.keywords||[]).some(kw=>text.includes(kw));
  });
  if(!pool.length){toast('此群組尚無相關題目，請先匯入題目');return;}
  toast(group.name+': 找到 '+pool.length+' 題');
  startQWithPool(pool, group.name);
  }catch(e){ logError('openConceptGroup',e); }}

async function renderGroups(){  try{
  const groups=_loadGroups();
  const qs=await da('questions');
  const el=document.getElementById('group-list');
  if(!el)return;

  const toolHtml='<div style="padding:0 12px 10px;display:flex;gap:8px;align-items:center">'
    +'<button class="btn bp" style="padding:10px;font-size:13px;flex:1" onclick="addGroupItem()">＋ 新增群組</button>'
    +'<button class="btn bg" style="padding:10px;font-size:13px" onclick="editGroupList()">✏ 管理</button>'
  +'</div>';

  if(!groups.length){
    el.innerHTML=toolHtml+'<div class="empty" style="margin:20px 0"><span class="ic">🧩</span><span>尚無群組，點上方「＋ 新增群組」建立</span></div>';
    return;
  }

  const cardsHtml=groups.map((g,i)=>{
    const count=qs.filter(q=>{
      const text=(q.stem||'')+Object.values(q.options||{}).join('')+(q.keywords||[]).join('');
      return (g.keywords||[]).some(kw=>text.includes(kw));
    }).length;
    return '<div class="card" style="margin:5px 12px;cursor:pointer" onclick="openConceptGroup('+i+')">'
      +'<div style="display:flex;align-items:center;gap:10px">'
        +'<span style="font-size:24px">'+(g.icon||'🧩')+'</span>'
        +'<div style="flex:1">'
          +'<div style="font-size:14px;font-weight:700">'+esc(g.name)+'</div>'
          +(g.desc?'<div style="font-size:11px;color:var(--t2);margin-top:2px">'+esc(g.desc)+'</div>':'')
          +((g.laws||[]).length?'<div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:5px">'+(g.laws||[]).map(l=>'<span class="tag" style="color:var(--pur)">'+esc(l)+'</span>').join('')+'</div>':'')
        +'</div>'
        +'<div style="text-align:right">'
          +'<div style="font-size:18px;font-weight:700;color:var(--acc)">'+count+'</div>'
          +'<div style="font-size:10px;color:var(--t2)">相關題</div>'
        +'</div>'
      +'</div>'
    +'</div>';
  }).join('');

  el.innerHTML=toolHtml+cardsHtml;
  }catch(e){ logError('renderGroups',e); }}

async function startNumberMode(){  try{
  const qs=await da('questions');
  const pool=extractNumberQuestions(qs);
  if(!pool.length){toast('沒有含數字的題目');return;}
  toast('數字魔鬼：共 '+pool.length+' 題');
  startQWithPool(pool,'number');
  }catch(e){ logError('startNumberMode',e); }}

// ── Cloze 挖空模式 ─────────────────────────────────────────
function renderCloze(){ toast('請先開啟一個法規，再點「挖空練習」'); }

function startClozeLaw(content, lawName){
  var cloze=generateCloze(content||'', 0.35);
  var el=document.getElementById('lbody');
  if(!el) return;
  var parts=cloze.split('【　　　】');
  var html='<div style="padding:12px">'
    +'<div style="font-size:12px;color:var(--org);margin-bottom:8px">📝 挖空練習 — 試著填入空白</div>'
    +'<div style="font-size:15px;line-height:2.2;color:var(--t1)">';
  for(var i=0;i<parts.length;i++){
    html+=esc(parts[i]);
    if(i<parts.length-1)
      html+='<span style="display:inline-block;min-width:60px;border-bottom:2px solid var(--pur);margin:0 4px">&nbsp;</span>';
  }
  html+='</div>';
  el.innerHTML=html;
  var btn=document.createElement('button');
  btn.className='btn bg bw';
  btn.style.cssText='margin-top:12px;padding:12px';
  btn.textContent='📖 顯示原文';
  btn.onclick=function(){ openLawGroup(lawName||''); };
  el.appendChild(btn);
}


function addConceptGroup(){
  showConceptGroupSheet(null);
}

async function editConceptGroup(id){
  const groups=_loadGroups();
  const g=groups.find(g=>g.id===id);
  if(g) showConceptGroupSheet(g);
}

async function delConceptGroupById(id){  try{
  if(!confirm('確定刪除此群組？'))return;
  await deleteConceptGroup(id);
  toast('已刪除');
  renderGroups();
  }catch(e){ logError('delConceptGroupById',e); }}

function showConceptGroupSheet(g){
  S._editGroupId=g?.id||null;
  document.getElementById('cg-name').value=g?.name||'';
  document.getElementById('cg-icon').value=g?.icon||'📌';
  document.getElementById('cg-desc').value=g?.desc||'';
  document.getElementById('cg-keywords').value=(g?.keywords||[]).join(',');
  document.getElementById('cg-laws').value=(g?.laws||[]).join(',');
  document.getElementById('cg-ov').classList.add('on');
}

// closeCGSheet 已移除（整合到 closeGroupAdd）

async function saveCGSheet(){  try{
  const name=document.getElementById('cg-name').value.trim();
  if(!name){toast('請填寫群組名稱');return;}
  const data={
    name,
    icon:document.getElementById('cg-icon').value.trim()||'📌',
    desc:document.getElementById('cg-desc').value.trim(),
    keywords:document.getElementById('cg-keywords').value.split(/[,，]/).map(s=>s.trim()).filter(Boolean),
    laws:document.getElementById('cg-laws').value.split(/[,，]/).map(s=>s.trim()).filter(Boolean),
  };
  if(S._editGroupId) data.id=S._editGroupId;
  await saveConceptGroup(data);
  closeGroupAdd();
  toast(S._editGroupId?'群組已更新 ✓':'群組已新增 ✓');
  renderGroups();
  }catch(e){ logError('saveCGSheet',e); }}


// ── 概念群組管理 ─────────────────────────────────────────────
function editGroupList(){
  const groups=_loadGroups();
  const el=document.getElementById('group-list');
  if(!el)return;
  el.innerHTML='<div style="padding:0 12px 10px">'
    +'<div style="font-size:13px;font-weight:700;margin-bottom:8px">群組管理</div>'
    +groups.map((g,i)=>
      '<div style="display:flex;align-items:center;gap:6px;margin-bottom:6px;padding:8px;background:var(--bg2);border-radius:8px">'
        +'<span style="font-size:18px">'+g.icon+'</span>'
        +'<span style="flex:1;font-size:13px">'+esc(g.name)+'</span>'
        +'<button class="btn bg" style="padding:4px 8px;font-size:11px" onclick="addGroupItem('+i+')">✏</button>'
        +'<button style="background:none;border:none;color:var(--red);cursor:pointer;font-size:14px" onclick="delGroupItem('+i+')">🗑</button>'
      +'</div>'
    ).join('')
    +'<button class="btn bp bw" style="padding:10px;font-size:13px;margin-top:6px" onclick="addGroupItem()">＋ 新增群組</button>'
    +'<button class="btn bg bw" style="padding:10px;font-size:13px;margin-top:6px" onclick="renderGroups()">← 返回</button>'
  +'</div>';
}

function addGroupItem(editIdx){
  const groups=_loadGroups();
  const isEdit=editIdx!==undefined&&editIdx>=0;
  const g=isEdit?groups[editIdx]:{};
  // 儲存到 window 供 saveGroupItem 備用
  window._editGroupIdx=isEdit?editIdx:-1;
  window._groupForm={
    icon:g.icon||'📌', name:g.name||'',
    desc:g.desc||'', kw:(g.keywords||[]).join(','), laws:(g.laws||[]).join(',')
  };
  // 先設值（display:none 下 value 設定仍有效）
  const setVals=()=>{
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.value=v;};
    set('cg-icon',window._groupForm.icon);
    set('cg-name',window._groupForm.name);
    set('cg-desc',window._groupForm.desc);
    set('cg-kw',window._groupForm.kw);
    set('cg-laws',window._groupForm.laws);
    const t=document.getElementById('group-add-title');
    if(t)t.textContent=isEdit?'編輯概念群組':'新增概念群組';
  };
  setVals(); // 立即設一次
  const ov=document.getElementById('group-add-ov');
  if(ov) ov.classList.add('on');
  // overlay 動畫結束後再設一次（保險）
  setTimeout(setVals, 250);
}

function closeGroupAdd(){
  const ov=document.getElementById('group-add-ov');
  if(ov) ov.classList.remove('on');
}

function saveGroupItem(){
  // 先強制從 DOM 更新 _groupForm（如果 DOM 有值就覆蓋）
  const gf=window._groupForm||{};
  const sync=(id,key)=>{const el=document.getElementById(id);if(el&&el.value)gf[key]=el.value;};
  sync('cg-icon','icon'); sync('cg-name','name');
  sync('cg-desc','desc'); sync('cg-kw','kw'); sync('cg-laws','laws');
  const icon=(gf.icon||'📌').trim();
  const name=(gf.name||'').trim();
  if(!name){toast('請填寫群組名稱');return;}
  const desc=(gf.desc||'').trim();
  const kwStr=gf.kw||'';
  const lawStr=gf.laws||'';
  const groups=_loadGroups();
  const item={
    id:'g_'+Date.now(),
    name,icon,desc,
    keywords:kwStr.split(/[,，]/).map(s=>s.trim()).filter(Boolean),
    laws:lawStr.split(/[,，]/).map(s=>s.trim()).filter(Boolean)
  };
  const idx=window._editGroupIdx;
  if(idx>=0&&idx<groups.length){
    item.id=groups[idx].id;
    groups[idx]=item;
    toast('群組已更新');
  } else {
    groups.push(item);
    toast('群組「'+name+'」已新增');
  }
  _saveGroups(groups);
  closeGroupAdd();
  renderGroups();
}

function editGroupItem(i){ addGroupItem(i); }

function delGroupItem(i){
  const groups=_loadGroups();
  const g=groups[i];if(!g)return;
  if(!confirm('確定刪除「'+g.name+'」？'))return;
  groups.splice(i,1);
  _saveGroups(groups);
  toast('已刪除');
  editGroupList();
}

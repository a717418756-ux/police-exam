// ══ quiz.js — 刷題模式（含遺忘曲線、計時、危險等級）══════
// 依賴：db.js, utils.js

let _qStart=0; // 題目開始時間

async function startQ(mode){  try{
  const pool=await getPriorityPool(mode);
  if(!pool.length){toast(mode==='wrong'?'目前沒有錯題':'目前沒有題目');return;}
  startQWithPool(pool, mode);
  }catch(e){ logError('startQ',e); }}

function startQWithPool(pool, mode){
  S.quiz={q:pool, idx:0, ans:false, res:[], mode:mode||'all', _selected:new Set()};
  // 確保 qfoot 可見（showQDone 會隱藏）
  const qfoot=document.getElementById('qfoot');
  if(qfoot) qfoot.style.display='';
  renderQCard();
  document.getElementById('qv').style.display='flex';
}

function renderQCard(){
  const {q,idx}=S.quiz;
  if(idx>=q.length){showQDone();return;}
  const qu=q[idx];
  _qStart=Date.now();
S.quiz._selected=new Set();

// 恢復被 showQDone 隱藏的元素
['qbadge','qmeta','q-type-hint','qstem','qopts','qres'].forEach(id=>{
  const el=document.getElementById(id); if(el)el.style.display='';
});
const _doneArea=document.getElementById('qdone-area');
if(_doneArea){_doneArea.style.display='none';_doneArea.innerHTML='';}
const _qfoot=document.getElementById('qfoot');
if(_qfoot) _qfoot.style.display='';


  // 進度
  document.getElementById('qpb').style.width=((idx/q.length)*100)+'%';
  document.getElementById('qct').textContent=(idx+1)+'/'+q.length;

  // 題型 badge + 危險等級
  const danger=qu._danger||'';
  document.getElementById('qbadge').className='badge '+(qu.type==='mc'?'bmc':'bes');
  document.getElementById('qbadge').textContent=(qu.type==='mc'?'選擇':'申論');
  document.getElementById('qmeta').textContent=
    [qu.subject,qu.year,qu.num?'第'+qu.num+'題':'',danger].filter(Boolean).join(' · ');

  // 題幹
  document.getElementById('qstem').textContent=qu.stem||'';
  document.getElementById('qres').className='qres';
  document.getElementById('qres').textContent='';
  const noteEl=document.getElementById('qnote');
  noteEl.style.display='none';noteEl.textContent='';

  // 收藏
  const star=document.getElementById('qstar');
  star.className='qfb qstar'+(qu.starred?' on':'');
  star.textContent=qu.starred?'★':'☆';

  // 下一題按鈕
  document.getElementById('qnxt').classList.add('hide');


  if(qu.type==='mc'){
    document.getElementById('qes').style.display='none';
    const optsEl=document.getElementById('qopts');
    const ansStr=(qu.answer||'').replace(/[, ]/g,'');
    const isMulti=ansStr.length>1;
    S.quiz._selected=new Set();
    // (7) 提示文字
    const hintEl=document.getElementById('q-type-hint');
    if(hintEl) hintEl.textContent=isMulti?'🔢 複選題（可選多個）':'☑ 單選題';
    // 更新 meta
    const meta=document.getElementById('qmeta');
    if(meta) meta.textContent=[qu.subject,qu.year,qu.num?'第'+qu.num+'題':''].filter(Boolean).join(' · ');
    const optHtml=Object.entries(qu.options||{}).map(([k,v])=>{
      return '<div class="qopt" data-key="'+k+'" onclick="selectOptByEl(this)"><div class="qok">'+k+'</div><div class="qov">'+esc(v)+'</div></div>';
    }).join('');
    optsEl.innerHTML=optHtml;
    // 顯示 qfoot 裡的確認按鈕
    const cfmBtn=document.getElementById('qmulti-confirm');
    if(cfmBtn) cfmBtn.classList.remove('hide');
    // (7) 相關法條先隱藏，確認後顯示
    const lawEl=document.getElementById('qlaw');
    if(lawEl) lawEl.style.display='none';
  } else {
    document.getElementById('qopts').innerHTML='';
    document.getElementById('qes').style.display='block';
    document.getElementById('qrevbtn').textContent='顯示參考答案 / 解析';
    document.getElementById('qrevbtn').disabled=false;
    // 申論題：隱藏「確認答案」，等 revealES 後才顯示「下一題」
    const cfmBtnEs=document.getElementById('qmulti-confirm');
    if(cfmBtnEs) cfmBtnEs.classList.add('hide');
    showQLawLinks(qu);
  }
}

function showQLawLinks(qu){
  const lawEl=document.getElementById('qlaw');
  const listEl=document.getElementById('qlaw-list');
  const laws=qu.relatedLaws||[];
  if(!laws.length){lawEl.style.display='none';return;}
  listEl.innerHTML=laws.map(l=>
    `<span class="tag" style="color:var(--pur);cursor:pointer"
      onclick="showLawPop('${esc(l.ref||l.lawName||'')}')">⚖ ${esc(l.ref||l.lawName||'')}</span>`
  ).join('');
  lawEl.style.display='block';
}

// ── 多選題 ──────────────────────────────────────────────────
function toggleMultiOpt(k){
  if(S.quiz.ans)return;
  if(!window._multiSelected)window._multiSelected=new Set();
  if(window._multiSelected.has(k)){
    window._multiSelected.delete(k);
    const el=document.getElementById('qopt-'+k);
    if(el)el.classList.remove('selected-opt');
  } else {
    window._multiSelected.add(k);
    const el=document.getElementById('qopt-'+k);
    if(el)el.classList.add('selected-opt');
  }
}

async function confirmMultiAns(){  try{
  if(S.quiz.ans)return;
  const qu=S.quiz.q[S.quiz.idx];
  const sel=[...window._multiSelected].sort().join('');
  const ans=(qu.answer||'').toUpperCase().split('').sort().join('');
  await ansQ(sel, true); // true = 多選模式
  }catch(e){ logError('confirmMultiAns',e); }}

async function ansQ(sel, isMultiMode=false){  try{
  const qu=S.quiz.q[S.quiz.idx];
  if(S.quiz.ans)return;
  S.quiz.ans=true;
  const responseTime=Date.now()-_qStart;

  const isMulti=qu.multiAnswer||(qu.answer&&qu.answer.length>1&&/^[A-E]{2,}$/.test(qu.answer));
  const normSel=isMultiMode?sel:(sel||'').toUpperCase().split('').sort().join('');
  const normAns=(qu.answer||'').toUpperCase().split('').sort().join('');
  const correct=normSel===normAns;
  const hesitant=responseTime>40000;

  // 更新遺忘曲線
  const curLevel=qu.reviewLevel||0;
  const {level:newLevel, next:nextReview}=calcNextReview(curLevel, correct);
  qu.reviewLevel=newLevel;
  qu.nextReview=nextReview;
  qu.lastReview=Date.now();
  qu.wrongCount=(qu.wrongCount||0)+(correct?0:1);
  qu.correctStreak=correct?(qu.correctStreak||0)+1:0;
  // 難度分數（答錯或猶豫提高）
  qu.difficultyScore=Math.min(10,
    (qu.difficultyScore||5)+(correct?(hesitant?0:-0.5):1.5)
  );
  await dp('questions',qu);

  // 記錄 attempt（含時間）
  await dp('attempts',{
    qid:qu.id, correct,
    date:today(),
    responseTime,
    hesitationFlag:hesitant,
    confidence:hesitant?'low':'normal',
    wrongReason:correct?'':'未知'
  });

  // 顯示結果
  const opts=document.querySelectorAll('.qopt');
  const correctKeys=(qu.answer||'').toUpperCase().split('');
  const selKeys=isMultiMode?[...window._multiSelected]:[sel.toUpperCase()];
  opts.forEach(o=>{
    const k=o.querySelector('.qok')?.textContent;
    if(!k)return;
    const isCorrectKey=correctKeys.includes(k);
    const isSelected=selKeys.includes(k);
    o.classList.remove('selected-opt');
    if(isCorrectKey) o.classList.add('correct');
    else if(isSelected) o.classList.add('wrong');
    else o.classList.add('dim');
  });
  // 隱藏確認按鈕（不能 remove，下一題還要用）
  const cfmBtn=document.getElementById('qmulti-confirm');
  if(cfmBtn)cfmBtn.classList.add('hide');

  const resEl=document.getElementById('qres');
  resEl.className='qres on '+(correct?'c':'w');
  const isMultiQ=qu.multiAnswer||(qu.answer&&qu.answer.length>1&&/^[A-E]{2,}$/.test(qu.answer));
  let msg=correct?'✓ 正確！':'✗ 正確答案：'+(qu.answer||'')+(isMultiQ?' (多選)':'');
  if(hesitant) msg+=' ⚠ 作答超過40秒，列入猶豫題';
  resEl.textContent=msg;

  if(qu.note){
    const noteEl=document.getElementById('qnote');
    noteEl.style.display='block';noteEl.textContent='📝 '+qu.note;
  }
  document.getElementById('qnxt').classList.remove('hide');


  S.quiz.res.push({qid:qu.id,correct,responseTime,hesitant});
  }catch(e){ logError('ansQ',e); }}

function revealES(){
  const qu=S.quiz.q[S.quiz.idx];
  const ans=qu.answerEs||qu.answer||'';
  const resEl=document.getElementById('qres');
  resEl.className='qres on r';
  resEl.innerHTML='<b>參考解析：</b><br>'+esc(ans);

  // 申論題關鍵字檢測
  const must=qu.mustKeywords||[];
  if(must.length){
    resEl.innerHTML+='<br><br><b>關鍵字檢測：</b><br>';
    const userAns=(document.getElementById('qes-input')?.value||'');
    must.forEach(kw=>{
      const hit=userAns.includes(kw);
      resEl.innerHTML+=`<span style="color:${hit?'var(--grn)':'var(--red)'}">${hit?'✓':'✗'} ${esc(kw)}</span>  `;
    });
  }

  document.getElementById('qrevbtn').disabled=true;
  document.getElementById('qnxt').classList.remove('hide');

  const responseTime=Date.now()-_qStart;
  dp('attempts',{qid:qu.id,correct:null,date:today(),responseTime,hesitationFlag:responseTime>40000});
}

function nextQ(){
  S.quiz.idx++;
  S.quiz.ans=false;
  renderQCard();
}

function exitQ(){
  document.getElementById('qv').style.display='none';
  S.quiz={q:[],idx:0,ans:false,res:[],mode:''};
  if(S.page==='home')renderHome();
}

async function toggleQStar(){  try{
  const qu=S.quiz.q[S.quiz.idx];
  if(!qu)return;
  qu.starred=!qu.starred;
  await dp('questions',qu);
  const star=document.getElementById('qstar');
  star.className='qfb qstar'+(qu.starred?' on':'');
  star.textContent=qu.starred?'★':'☆';
  toast(qu.starred?'已收藏 ⭐':'已取消收藏');
  }catch(e){ logError('toggleQStar',e); }}

function showQDone(){
  const res=S.quiz.res;
  const total=res.length;
  const correct=res.filter(r=>r.correct).length;
  const hesitant=res.filter(r=>r.hesitant).length;
  const avgTime=total?Math.round(res.reduce((s,r)=>s+(r.responseTime||0),0)/total/1000):0;
  const pct=total?Math.round(correct/total*100):0;
  const emoji=pct>=90?'🏆':pct>=70?'🎉':pct>=50?'💪':'📚';
  // 保存 pool 供重播用
  window._lastPool=[...S.quiz.q];
  window._lastMode=S.quiz.mode;

  // 隱藏題目相關元素，顯示完成區塊（不覆蓋 qbody，保留所有子元素）
  const hideIds=['qbadge','qmeta','q-type-hint','qstem','qopts','qres','qnote','qes','qlaw'];
  hideIds.forEach(id=>{ const el=document.getElementById(id); if(el)el.style.display='none'; });

  const doneArea=document.getElementById('qdone-area');
  if(doneArea){
    doneArea.style.display='flex';
    doneArea.innerHTML=
      '<div style="font-size:48px">'+emoji+'</div>'+
      '<div style="font-size:22px;font-weight:700">'+correct+'/'+total+' 正確</div>'+
      '<div style="font-size:14px;color:var(--t2)">正確率 '+pct+'%</div>'+
      (hesitant?'<div style="font-size:13px;color:var(--org)">⚠ '+hesitant+' 題猶豫超過40秒</div>':'')+
      '<div style="font-size:13px;color:var(--t2)">平均作答 '+avgTime+' 秒</div>'+
      '<div style="display:flex;flex-direction:column;gap:8px;margin-top:16px;width:100%">'+
      '<button class="btn bp bw" style="padding:14px;font-size:15px" onclick="replayQuiz()">🔄 再練習一次</button>'+
      '<button class="btn bg bw" style="padding:12px;font-size:14px" onclick="exitQ()">← 返回首頁</button>'+
      '</div>';
  }
  document.getElementById('qfoot').style.display='none';
}

function replayQuiz(){
  // 重新打亂順序再練一次
  const pool=window._lastPool||[];
  const mode=window._lastMode||'all';
  if(!pool.length){exitQ();return;}
  // Fisher-Yates 洗牌
  const shuffled=[...pool];
  for(let i=shuffled.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [shuffled[i],shuffled[j]]=[shuffled[j],shuffled[i]];
  }
  startQWithPool(shuffled, mode);
}

async function recAttempt(qid,correct){  try{
  await dp('attempts',{qid,correct,date:today(),responseTime:0,hesitationFlag:false});
  }catch(e){ logError('recAttempt',e); }}

// ── 模擬考模式 ──────────────────────────────────────────────
async function startExam(totalQ=50, timeLimitMin=50){  try{
  const pool=await getPriorityPool('all');
  if(pool.length<5){toast('題目不足，請先匯入題目');return;}
  const selected=pool.slice(0,Math.min(totalQ,pool.length));
  S.examTimeLimit=timeLimitMin*60*1000;
  S.examStart=Date.now();
  startQWithPool(selected,'exam');
  // 計時器
  if(S._examTimer)clearInterval(S._examTimer);
  S._examTimer=setInterval(()=>{
    const left=S.examTimeLimit-(Date.now()-S.examStart);
    if(left<=0){clearInterval(S._examTimer);toast('時間到！');showQDone();return;}
    const m=Math.floor(left/60000),s=Math.floor((left%60000)/1000);
    const el=document.getElementById('qct');
    if(el) el.textContent=`⏱${m}:${s.toString().padStart(2,'0')} · ${S.quiz.idx+1}/${selected.length}`;
  },1000);
  }catch(e){ logError('startExam',e); }}

// ── 快刷模式（5題/3分鐘）─────────────────────────────────
async function startQuick(){  try{
  const pool=await getPriorityPool('all');
  if(!pool.length){toast('沒有題目');return;}
  // 優先危險題，取5題
  const selected=pool.filter(q=>q._danger==='🔴'||q._danger==='🟠').slice(0,3)
    .concat(pool.slice(0,5)).slice(0,5);
  startQWithPool([...new Set(selected)],'quick');
  }catch(e){ logError('startQuick',e); }}

// ── 多選題支援 ──────────────────────────────────────────────
function selectOptByEl(el){ selectOpt(el, el.dataset.key); }
function selectOpt(el, key){
  if(S.quiz.ans)return;
  if(!S.quiz._selected) S.quiz._selected=new Set();
  const qu=S.quiz.q[S.quiz.idx];
  if(!qu)return; // 防呆：quiz 尚未開始
  const ansStr=(qu.answer||'').replace(/[, ]/g,'');
  const isMulti=ansStr.length>1;
  if(isMulti){
    // 複選：切換
    if(S.quiz._selected.has(key)){
      S.quiz._selected.delete(key);
      el.classList.remove('selected');
    } else {
      S.quiz._selected.add(key);
      el.classList.add('selected');
    }
  } else {
    // 單選：只能選一個，切換選取
    document.querySelectorAll('.qopt').forEach(o=>o.classList.remove('selected'));
    S.quiz._selected.clear();
    if(true){ // 總是選取點擊的
      S.quiz._selected.add(key);
      el.classList.add('selected');
    }
  }
}

function submitMulti(){
  if(S.quiz.ans)return;
  const qu=S.quiz.q[S.quiz.idx];
  const selected=[...(S.quiz._selected||new Set())].sort().join('');
  const ansStr=(qu.answer||'').replace(/[, ]/g,'').split('').sort().join('');
  ansQMulti(selected, ansStr, qu);
}

async function ansQMulti(selected, correctStr, qu){  try{
  S.quiz.ans=true;
  const responseTime=Date.now()-_qStart;
  const correct=selected===correctStr;
  const hesitant=responseTime>40000;
  const curLevel=qu.reviewLevel||0;
  const {level:newLevel, next:nextReview}=calcNextReview(curLevel, correct);
  qu.reviewLevel=newLevel; qu.nextReview=nextReview; qu.lastReview=Date.now();
  qu.wrongCount=(qu.wrongCount||0)+(correct?0:1);
  qu.correctStreak=correct?(qu.correctStreak||0)+1:0;
  qu.difficultyScore=Math.min(10,(qu.difficultyScore||5)+(correct?(hesitant?0:-0.5):1.5));
  await dp('questions',qu);
  await dp('attempts',{qid:qu.id,correct,date:today(),responseTime,hesitationFlag:hesitant,confidence:hesitant?'low':'normal',wrongReason:correct?'':''});
  const opts=document.querySelectorAll('.qopt');
  opts.forEach(o=>{
    const k=o.querySelector('.qok')?.textContent||'';
    const inCorrect=correctStr.includes(k);
    const inSelected=(S.quiz._selected||new Set()).has(k);
    if(inCorrect&&inSelected) o.classList.add('correct');
    else if(inCorrect&&!inSelected) o.classList.add('missed');
    else if(!inCorrect&&inSelected) o.classList.add('wrong');
    else o.classList.add('dim');
  });
  const resEl=document.getElementById('qres');
  resEl.className='qres on '+(correct?'c':'w');
  let msg=correct?'✓ 完全正確！':'✗ 正確答案：'+correctStr.split('').join('、');
  if(!correct&&selected) msg+='（你選：'+selected.split('').join('、')+'）';
  if(hesitant) msg+=' ⚠ 超過40秒';
  resEl.textContent=msg;
  if(qu.note){const noteEl=document.getElementById('qnote');noteEl.style.display='block';noteEl.textContent='📝 '+qu.note;}
  document.getElementById('qnxt').classList.remove('hide');

  // 隱藏確認按鈕
  const cfmBtn2=document.getElementById('qmulti-confirm');
  if(cfmBtn2) cfmBtn2.classList.add('hide');
  S.quiz.res.push({qid:qu.id,correct,responseTime,hesitant});
  showQLawLinks(qu);
  }catch(e){ logError('ansQMulti',e); }}

function submitAnswer(){
  const qu=S.quiz.q[S.quiz.idx];
  if(!qu||S.quiz.ans)return; // 防呆：qu 未定義或已作答
  // 申論題直接顯示解析，不卡「請先選擇答案」
  if(qu.type==='es'){revealES();return;}
  const ansStr=(qu.answer||'').replace(/[, ]/g,'');
  const isMulti=ansStr.length>1;
  if(isMulti){
    submitMulti();
  } else {
    const sel=[...(S.quiz._selected||new Set())][0];
    if(!sel){toast('請先選擇答案');return;}
    ansQ(sel);
  }
}

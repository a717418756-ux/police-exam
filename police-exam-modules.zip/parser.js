// ══ parser.js — 超高容錯解析引擎 v3 ═══════════════════════
// 依賴：utils.js (autoKeywords, norm, art2n, kwArr)

// ── OCR 錯字對照 ────────────────────────────────────────────
const OCR_FIX = {
  '職橾':'職權','職棰':'職權','職権':'職權',
  '集會游行':'集會遊行','行政執亍':'行政執行',
  '即時強制力':'即時強制','社維法':'社會秩序維護法',
  '止當法律':'正當法律','比例庵則':'比例原則',
};

// ── 選項符號對照表（NFKC 前處理）────────────────────────────
const OPT_SYMBOL_MAP = {
  // 圓圈數字 → 直接對應 A B C D E
  '①':'A','②':'B','③':'C','④':'D','⑤':'E',
  '❶':'A','❷':'B','❸':'C','❹':'D','❺':'E',
  '⑴':'A','⑵':'B','⑶':'C','⑷':'D','⑸':'E',
  'ㄅ':'A','ㄆ':'B','ㄇ':'C','ㄈ':'D',
  // 方塊/圓形符號 → 無名選項分隔 §OPT§
  '☒':'§OPT§','☐':'§OPT§','□':'§OPT§','■':'§OPT§',
  '▢':'§OPT§','◯':'§OPT§','○':'§OPT§','●':'§OPT§',
  '◉':'§OPT§','◎':'§OPT§','▪':'§OPT§','▫':'§OPT§',
  '◆':'§OPT§','◇':'§OPT§','▶':'§OPT§','▷':'§OPT§',
  '►':'§OPT§','▸':'§OPT§','‣':'§OPT§',
};

// ── 1. preprocessQuestionText ───────────────────────────────
function preprocessQuestionText(text){
  if(!text) return '';
  let t = text;

  // OCR 錯字修正
  Object.entries(OCR_FIX).forEach(([wrong,right])=>{ t=t.split(wrong).join(right); });

  // 選項符號替換（必須在 NFKC 前，否則 ①→1）
  Object.entries(OPT_SYMBOL_MAP).forEach(([sym,val])=>{
    if(val==='§OPT§'){
      t=t.split(sym).join('§OPT§');
    } else {
      t=t.split(sym).join('§'+val+'§');
    }
  });

  // PDF 私有字元（U+E000–U+F8FF）偵測：重複3次以上視為選項符號
  const pvtMap={};
  for(const ch of t){
    const cp=ch.codePointAt(0);
    if(cp>=0xE000&&cp<=0xF8FF) pvtMap[ch]=(pvtMap[ch]||0)+1;
  }
  const pvtSep=Object.entries(pvtMap).filter(([,n])=>n>=3).sort((a,b)=>b[1]-a[1])[0];
  if(pvtSep) t=t.split(pvtSep[0]).join('§OPT§');

  // NFKC 正規化（全形→半形）
  t=t.normalize('NFKC');

  // 換行統一
  t=t.replace(/\r\n/g,'\n').replace(/\r/g,'\n');

  // ★ 全行格式：在選項和題號前插入換行
  // 讓「...委員會 (B)...」→「...委員會\n(B)...」
  // 讓「...委員會 2. 下一題」→「...委員會\n2. 下一題」
  t=t.replace(/([^(\n])\s*\(([A-Ea-e])\)/g,'$1\n($2)');
  t=t.replace(/([\u4e00-\u9fff\uff00-\uffef\u3000-\u303f）)\]】」])\s*(\d{1,3}[.、．]\s)/g,'$1\n$2');

  // 不可見字元清除
  t=t.replace(/[\u00A0\u200B\u200C\u200D\uFEFF]/g,'').replace(/\u3000/g,' ');

  // 全形括號選項：（A）(A) → §A§
  t=t.replace(/[（(]\s*([A-Ea-e])\s*[）)]/g,(_,k)=>'§'+k.toUpperCase()+'§');

  // 讓選項各自換行（§OPT§ 和 §A§ 前後加換行）
  t=t.replace(/([^\n])§OPT§/g,'$1\n§OPT§');
  t=t.replace(/([^\n])§([A-E])§/g,'$1\n§$2§');
  t=t.replace(/§([A-E])§\s*/g,'\n§$1§ ');
  t=t.replace(/§OPT§\s*/g,'\n§OPT§ ');

  // 中文字間多餘空格（保留數字前後）
  let prev='';
  let _wLim1=0;
  while(prev!==t&&_wLim1++<8){
    prev=t;
    t=t.replace(/([\u4e00-\u9fff，。！？、：；]) ([\u4e00-\u9fff，。！？、：；])/g,'$1$2');
  }

  // 行尾空白
  t=t.replace(/[ \t]+$/gm,'');

  return t.trim();
}

// ── 2. normalizeOptions ─────────────────────────────────────
function normalizeOptions(text){
  let t=text;
  // §OPT§ 依序轉為 §A§ §B§ ...（每題重置，在 parseQuestions 裡處理）
  let idx=0;
  const KEYS=['A','B','C','D','E'];
  t=t.replace(/§OPT§/g,()=>'§'+(KEYS[idx++]||'?')+'§ ');
  // 行首 (A 沒有右括號
  t=t.replace(/^[（(]\s*([A-Ea-e])\s+/gm,(_,k)=>'§'+k.toUpperCase()+'§ ');
  // 行首 A. A、
  t=t.replace(/^([A-Ea-e])[.、．]\s*/gm,(_,k)=>'§'+k.toUpperCase()+'§ ');
  return t;
}

// ── 3. parseQuestions 主解析函式 ───────────────────────────
function parseQuestions(rawText){
  if(!rawText||!rawText.trim()) return [];

  // 前處理
  let text=preprocessQuestionText(rawText);

  // 中文題號轉換
  const ZH={'一':'1','二':'2','三':'3','四':'4','五':'5','六':'6','七':'7','八':'8','九':'9','十':'10'};
  text=text.replace(/^([一二三四五六七八九十]+)[、．。.]/gm,(_,n)=>(ZH[n]||n)+'. ');
  text=text.replace(/^Q\s*(\d+)[.、]?\s*/gim,'$1. ');
  text=text.replace(/^第\s*(\d+)\s*題[.、]?\s*/gim,'$1. ');

  // 對每題的 §OPT§ 重置計數（用特殊佔位，稍後替換）
  // 先切題，各題內部再處理 §OPT§
  const Q_SPLIT=/(?=(?:^|\n)\s*\d{1,3}[.、．）)]\s*\S)/gm;
  const blocks=('\n'+text).split(Q_SPLIT)
    .map(b=>b.trim()).filter(b=>b.length>2);

  const questions=[];
  for(const block of blocks){
    const q=parseOneBlock(block);
    if(q) questions.push(q);
  }
  return questions;
}

// ── 4. parseOneBlock 單題解析 ───────────────────────────────
function parseOneBlock(block){
  // 每個 block 獨立處理 §OPT§ 計數
  let idx=0;
  const KEYS=['A','B','C','D','E'];
  let b=block.replace(/§OPT§/g,()=>'§'+(KEYS[idx++]||'?')+'§ ');

  // 行首 (A 和 A. 標準化
  b=b.replace(/^[（(]\s*([A-Ea-e])\s+/gm,(_,k)=>'§'+k.toUpperCase()+'§ ');
  b=b.replace(/^([A-Ea-e])[.、．]\s*/gm,(_,k)=>'§'+k.toUpperCase()+'§ ');

  const lines=b.split('\n');
  let num='?', stem='';
  const options={};
  let curKey=null;

  for(let i=0;i<lines.length;i++){
    const t=lines[i].trim();
    if(!t) continue;

    // 選項行
    const optM=t.match(/^§([A-E])§\s*(.*)/);
    if(optM){
      const key=optM[1];
      options[key]=optM[2].trim();
      curKey=key;
      // 下一行若不是選項/題號，繼續追加
      continue;
    }

    // 題號行
    const qM=t.match(/^(\d{1,3})[.、．）)]\s*(.*)/);
    if(qM&&i===0){
      num=qM[1]; stem=qM[2].trim();
      curKey=null;
      continue;
    }

    // 「1 題目」空格格式
    const qSpaceM=(i===0&&!curKey)?t.match(/^(\d{1,3})\s+(\S.{2,})/):null;
    if(qSpaceM&&parseInt(qSpaceM[1])<=500){
      num=qSpaceM[1]; stem=qSpaceM[2].trim();
      curKey=null;
      continue;
    }

    // 追加
    if(curKey&&options[curKey]!==undefined){
      options[curKey]+=' '+t;
    } else {
      stem+=(stem?' ':'')+t;
    }
  }

  const optCount=Object.keys(options).length;
  const finalStem=cleanSpaces(stem.trim());
  if(!finalStem) return null;

  return {
    num, type:optCount>=2?'mc':'es',
    stem:finalStem,
    options:Object.fromEntries(Object.entries(options).map(([k,v])=>[k,cleanSpaces(v.trim())])),
    answer:'', answerEs:'',
    keywords:autoKeywords(finalStem),
    mustKeywords:autoKeywords(finalStem),
    tags:[], note:'', starred:false,
    createdAt:Date.now(),
    reviewLevel:0, nextReview:Date.now(), lastReview:null,
    wrongCount:0, correctStreak:0, difficultyScore:5,
  };
}

// ── 5. parseAnswerStr ────────────────────────────────────────
function parseAnswerStr(str){
  if(!str||!str.trim()) return {};
  const map={};
  for(const m of str.matchAll(/(\d{1,3})[.、\s]*([A-Ea-e])/g)){
    map[parseInt(m[1])]=m[2].toUpperCase();
  }
  return map;
}

// ── 6. parseBulkText（相容舊介面）──────────────────────────
function parseBulkText(text){
  return parseQuestions(text).map(q=>({
    ...q,
    answer:q.answer||'',
    answerEs:q.answerEs||'',
  }));
}

// ── 7. 數字題偵測 ────────────────────────────────────────────
function extractNumberQuestions(qs){
  // 偵測含數字時間/數量的題目（題幹或選項）
  const NUM_PAT=/\d+(?:日|小時|天|萬元|年|條|款|人|公尺|分鐘|秒|月|週|小時內|天內|日內|萬|千|百)/;
  return qs.filter(q=>{
    if(NUM_PAT.test(q.stem||''))return true;
    // 也搜尋選項
    return Object.values(q.options||{}).some(v=>NUM_PAT.test(v||''));
  });
}

// ── 8. 法條挖空 ──────────────────────────────────────────────
function generateCloze(content, rate=0.3){
  if(!content) return content;
  const segs=content.split(/(?<=。|，|；|：|、)/);
  return segs.map(s=>{
    if(Math.random()<rate&&s.length>2){
      return s.slice(0,Math.ceil(s.length/3))+'【　　　】';
    }
    return s;
  }).join('');
}

// ── 9. 法條分條解析 ─────────────────────────────────────────
function parseLawText(text, lawName, category, source){
  let t=norm(text||'');
  Object.entries(OCR_FIX).forEach(([w,r])=>{ t=t.split(w).join(r); });
  t=t.replace(/第\s+(\d+)\s+條/g,'第$1條'); // 只處理數字條號
  t=t.replace(/\u3000/g,' ');
  const parts=t.split(/(?=第\d+條(?:之\d+)?)/g)
    .map(p=>p.trim()).filter(Boolean);
  const items=[];
  for(const part of parts){
    const am=part.match(/^(第\d+條(?:之\d+)?)/);
    if(!am) continue;
    const article=am[1];
    const content=part.slice(article.length).trim();
    if(!content) continue;
    const NUM_PAT=/\d+(?:日|小時|天|萬元|年)/;
    items.push({
      lawName:lawName||'', article,
      articleNumber:art2n(article)||0,
      category:category||'statute', source:source||'',
      content, keywords:autoKeywords(content),
      hasNumberTrap:NUM_PAT.test(content),
      tags:[], relatedLaws:[], favorite:false, createdAt:Date.now()
    });
  }
  return items;
}

// finishQ 相容函式
function finishQ(q){ return q; }

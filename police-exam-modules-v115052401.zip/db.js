// ══ db.js — IndexedDB 核心 v3 ═══════════════════════════════
const DB_NAME='PoliceExamPro', DB_VER=3;
let db;

// 遺忘曲線複習間隔（天）
const REVIEW_INTERVALS=[1,3,7,14,30,60,180];

function initDB(){
  return new Promise((res,rej)=>{
    const r=indexedDB.open(DB_NAME,DB_VER);
    r.onupgradeneeded=e=>{
      const d=e.target.result;
      const oldVer=e.oldVersion;

      // questions store
      if(!d.objectStoreNames.contains('questions')){
        const s=d.createObjectStore('questions',{keyPath:'id',autoIncrement:true});
        s.createIndex('subject','subject',{unique:false});
        s.createIndex('createdAt','createdAt',{unique:false});
        s.createIndex('nextReview','nextReview',{unique:false});
        s.createIndex('reviewLevel','reviewLevel',{unique:false});
        s.createIndex('difficultyScore','difficultyScore',{unique:false});
        s.createIndex('type','type',{unique:false});
        s.createIndex('starred','starred',{unique:false});
      } else if(oldVer<3){
        // 升級：加新 index
        const tx=e.target.transaction;
        const s=tx.objectStore('questions');
        if(!s.indexNames.contains('nextReview')) s.createIndex('nextReview','nextReview',{unique:false});
        if(!s.indexNames.contains('reviewLevel')) s.createIndex('reviewLevel','reviewLevel',{unique:false});
        if(!s.indexNames.contains('difficultyScore')) s.createIndex('difficultyScore','difficultyScore',{unique:false});
      } else if(oldVer<4){
        // v4: 加 type, starred index
        try{
          const tx4=e.target.transaction;
          const s4=tx4.objectStore('questions');
          if(!s4.indexNames.contains('type')) s4.createIndex('type','type',{unique:false});
          if(!s4.indexNames.contains('starred')) s4.createIndex('starred','starred',{unique:false});
        }catch(ie4){ console.warn('v4 index migration:',ie4.message); }
      }

      // laws store
      if(!d.objectStoreNames.contains('laws')){
        const s=d.createObjectStore('laws',{keyPath:'id',autoIncrement:true});
        s.createIndex('lawName','lawName',{unique:false});
        s.createIndex('category','category',{unique:false});
        s.createIndex('articleNumber','articleNumber',{unique:false});
      }

      // attempts store（含新欄位）
      if(!d.objectStoreNames.contains('attempts')){
        const s=d.createObjectStore('attempts',{keyPath:'id',autoIncrement:true});
        s.createIndex('qid','qid',{unique:false});
        s.createIndex('date','date',{unique:false});
        s.createIndex('responseTime','responseTime',{unique:false});
      }
      if(!d.objectStoreNames.contains('conceptGroups')){
        d.createObjectStore('conceptGroups',{keyPath:'id',autoIncrement:true});
      }
    };
    r.onsuccess=e=>{db=e.target.result;res(db);};
    r.onerror=e=>rej(e.target.error);
  });
}

const dg=(st,k)=>new Promise((r,j)=>{const t=db.transaction(st,'readonly');const q=t.objectStore(st).get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>j();});
const da=(st,idx,qry)=>{
  // 無 idx/qry 的全量讀取才快取
  if(!idx&&!qry){
    const ckey=st;
    const cached=_cacheGet(ckey);
    if(cached)return Promise.resolve(cached);
    return new Promise((r,j)=>{
      const t=db.transaction(st,'readonly');
      const q=t.objectStore(st).getAll();
      q.onsuccess=()=>{_cacheSet(ckey,q.result);r(q.result);};
      q.onerror=()=>j([]);
    });
  }
  return new Promise((r,j)=>{const t=db.transaction(st,'readonly');const o=t.objectStore(st);const q=idx?o.index(idx).getAll(qry):o.getAll();q.onsuccess=()=>r(q.result);q.onerror=()=>j([]);});
};
const dp=(st,data)=>new Promise((r,j)=>{const t=db.transaction(st,'readwrite');const q=t.objectStore(st).put(data);q.onsuccess=()=>{_cacheInvalidate(st);r(q.result);};q.onerror=e=>j(e.target.error||new Error('dp failed'));t.onerror=e=>j(e.target.error||new Error('tx failed'));});
const dd=(st,k)=>new Promise((r,j)=>{const t=db.transaction(st,'readwrite');const req=t.objectStore(st).delete(k);req.onsuccess=()=>{_cacheInvalidate(st);r();};req.onerror=()=>j();});
const dc=(st)=>new Promise((r,j)=>{const t=db.transaction(st,'readwrite');const req=t.objectStore(st).clear();req.onsuccess=()=>{_cacheInvalidate(st);r();};req.onerror=()=>j();});

function bulkPut(st,items){
  return new Promise((res,rej)=>{
    const tx=db.transaction(st,'readwrite');
    const os=tx.objectStore(st);
    let n=0;
    tx.oncomplete=()=>{_cacheInvalidate(st);res(n);};
    tx.onerror=e=>rej(e);
    items.forEach(it=>{os.put(it).onsuccess=()=>n++;});
  });
}

// ── 錯誤記錄（輕量版，避免無聲失敗）────────────────────────
const _errLog=[];
function logError(context, err){
  const entry={t:new Date().toISOString(),ctx:context,msg:err?.message||String(err)};
  _errLog.push(entry);
  if(_errLog.length>50)_errLog.shift(); // 最多保留50筆
  console.error('[PoliceExam]',context,err);
}
// ── 輕量快取（避免重複全量讀取）────────────────────────────
const _cache={};
const _CACHE_TTL=30000; // 30秒 TTL（操作後自動失效）

function _cacheGet(key){
  const c=_cache[key];
  if(!c)return null;
  if(Date.now()-c.ts>_CACHE_TTL){delete _cache[key];return null;}
  return c.data;
}
function _cacheSet(key,data){ _cache[key]={data,ts:Date.now()}; }
function _cacheInvalidate(st){ delete _cache[st]; }

// ── 遺忘曲線核心 ────────────────────────────────────────────
function calcNextReview(level, correct){
  if(!correct){
    // 答錯：降級，明天再複習
    return {level:Math.max(0,level-1), next:Date.now()+86400000};
  }
  const newLevel=Math.min(level+1, REVIEW_INTERVALS.length-1);
  const days=REVIEW_INTERVALS[newLevel];
  return {level:newLevel, next:Date.now()+days*86400000};
}

// ── 取今日待複習題目 ────────────────────────────────────────
// ── 取今日新題（從未複習）────────────────────────────────────
// ── 危險等級計算 ─────────────────────────────────────────────
function getDangerLevel(q, recentAts){
  const qa=recentAts.filter(a=>a.qid===q.id).sort((a,b)=>b.date-a.date);
  const last3=qa.slice(0,3);
  const wrongStreak=last3.length>=2&&last3.every(a=>!a.correct);
  const lastWrong=last3.length>0&&!last3[0].correct;
  const hesitant=last3.some(a=>a.responseTime>40000);
  if(wrongStreak) return '🔴';  // 連錯2次以上
  if(lastWrong) return '🟠';   // 最近答錯
  if(hesitant) return '🟡';    // 猶豫超過40秒
  return '🟢';                  // 穩定
}

// ── 優先排序：危險題優先 ─────────────────────────────────────
async function getPriorityPool(mode='all'){  try{
  const [qs,ats]=await Promise.all([da('questions'),da('attempts')]);
  if(!qs.length) return [];
  const now=Date.now();

  // 測驗只取選擇題（申論題在題目閱覽瀏覽，不進測驗模式）
  const mcQs=qs.filter(q=>q.type==='mc');
  let pool=mcQs;
  if(mode==='wrong'){const ws=getWrong(qs,ats);pool=mcQs.filter(q=>ws.has(q.id));}
  else if(mode==='star'){pool=mcQs.filter(q=>q.starred);}
  else if(mode==='review'){pool=mcQs.filter(q=>(q.nextReview||0)<=now);}
  else if(mode==='new'){pool=mcQs.filter(q=>!q.reviewLevel&&q.reviewLevel!==0);}

  // 按危險等級排序
  const levelOrder={'🔴':0,'🟠':1,'🟡':2,'🟢':3};
  pool.sort((a,b)=>{
    const da_=getDangerLevel(a,ats);
    const db_=getDangerLevel(b,ats);
    return (levelOrder[da_]||3)-(levelOrder[db_]||3);
  });
  return pool;
  }catch(e){ logError('getPriorityPool',e); return []; }}

const APP_VER = 'v115052401';

// ══ nav.js — 導覽與初始化 ══════════════════════════════
// 依賴：全部模組

function goPage(pg,btn){
  document.querySelectorAll('.page').forEach(p=>p.classList.add('hide'));
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('on'));
  const el=document.getElementById('pg-'+pg);if(el)el.classList.remove('hide');
  if(btn)btn.classList.add('on');
  else{const b=document.querySelector(`.nb[onclick*="'${pg}'"]`);if(b)b.classList.add('on');}
  S.page=pg;
  ({home:renderHome,list:renderList,laws:renderDB,db:renderDB,stats:renderStats,set:renderSet,bulk:()=>{},groups:renderGroups})[pg]?.();
}

async function init(){  try{
  await initDB();
  buildOpts({});
  goPage('home',document.querySelector('.nb'));
  if(typeof applyIconSettings==='function') applyIconSettings();
  }catch(e){logError('init',e);document.body.innerHTML='<div style="padding:20px;color:red">⚠ 初始化失敗：'+e.message+'</div>';}
}
init().then(()=>{
  if(typeof applyCustomIcons==="function") applyCustomIcons();
  // 填入版本號
  const verEl=document.getElementById('app-ver');
  if(verEl) verEl.textContent=typeof APP_VER!=='undefined'?APP_VER:'';
});



if('serviceWorker' in navigator){window.addEventListener('load',()=>{navigator.serviceWorker.register('./sw.js').catch(()=>{});});}

// ── countdown.js：考試倒數功能 ──────────────────────────────────────
// 依賴：utils.js（esc, today）
// 儲存：localStorage 'examCountdowns' = [{id, name, date}]

const COUNTDOWN_KEY = 'examCountdowns';

function _loadCountdowns(){
  try{ return JSON.parse(localStorage.getItem(COUNTDOWN_KEY)||'[]'); }
  catch(e){ return []; }
}
function _saveCountdowns(list){
  try{ localStorage.setItem(COUNTDOWN_KEY, JSON.stringify(list)); }
  catch(e){}
}

// 計算距離考試的天數
function _daysUntil(dateStr){
  const now  = new Date(); now.setHours(0,0,0,0);
  const exam = new Date(dateStr); exam.setHours(0,0,0,0);
  return Math.round((exam - now) / 86400000);
}

// 渲染倒數區塊（首頁呼叫）
function renderCountdown(){
  const el = document.getElementById('h-countdown');
  if(!el) return;
  const list = _loadCountdowns().sort((a,b)=>new Date(a.date)-new Date(b.date));

  if(!list.length){
    el.innerHTML = '<div style="color:var(--t2);font-size:13px;padding:6px 0 2px">尚未新增考試，點下方按鈕新增</div>';
    return;
  }

  el.innerHTML = list.map(item=>{
    const days = _daysUntil(item.date);
    const isPast = days < 0;
    const isToday = days === 0;

    // 顏色：過期灰、今天紅、7天內橙、其他藍
    const col  = isPast ? 'var(--t2)'  : isToday ? 'var(--red)' : days<=7 ? 'var(--org)' : 'var(--acc)';
    const bg   = isPast ? 'var(--bg2)' : isToday ? 'rgba(248,81,73,0.10)' : days<=7 ? 'rgba(227,179,65,0.10)' : 'rgba(88,166,255,0.08)';
    const label= isPast ? `已過 ${Math.abs(days)} 天` : isToday ? '就是今天！' : `還有 ${days} 天`;
    const icon = isPast ? '📋' : isToday ? '🎯' : days<=7 ? '🔥' : '📅';

    return `<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;margin-bottom:8px;background:${bg};border-radius:10px;border-left:3px solid ${col}">
      <span style="font-size:20px">${icon}</span>
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:700;color:var(--t0);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(item.name)}</div>
        <div style="font-size:12px;color:var(--t2);margin-top:2px">${item.date}</div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-size:20px;font-weight:800;color:${col};line-height:1">${isPast?'－':days===0?'0':days}</div>
        <div style="font-size:10px;color:var(--t2)">${isPast?'天前':'天'}</div>
      </div>
      <button onclick="delCountdown('${item.id}')" style="background:none;border:none;color:var(--t2);font-size:16px;cursor:pointer;padding:0 2px;flex-shrink:0">×</button>
    </div>`;
  }).join('');
}

// 新增考試對話框
function openCountdownMgr(){
  const name = prompt('考試名稱（例：警佐二類升官等考試）：');
  if(!name||!name.trim()) return;
  const dateStr = prompt('考試日期（格式：2026-08-15）：');
  if(!dateStr||!/^\d{4}-\d{2}-\d{2}$/.test(dateStr.trim())){
    toast('日期格式不正確，請輸入 YYYY-MM-DD'); return;
  }
  const list = _loadCountdowns();
  list.push({ id: Date.now().toString(), name: name.trim(), date: dateStr.trim() });
  _saveCountdowns(list);
  renderCountdown();
  toast('已新增「'+name.trim()+'」');
}

// 刪除考試
function delCountdown(id){
  const list = _loadCountdowns().filter(i=>i.id!==id);
  _saveCountdowns(list);
  renderCountdown();
}


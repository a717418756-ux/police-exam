// ═══════════════════════════════════════════════════════════════════
// 新解析邏輯：按用戶指定的規則
// 規則1：行首是數字 → 題號，題幹讀到 ？ 或 ： 為止
// 規則2：行首是不明符號（重複出現）→ 選項分隔
// 規則3：選項跨行 → 遇到下一個符號前都追加到同一選項
// 規則4：(A)(B)/①② 等已知符號照常辨識
// 規則5：題目/選項內空格跳行整理整齊
// ═══════════════════════════════════════════════════════════════════

// ─────── 輔助：找題幹結尾（？ 或 ：）的位置 ──────────────────────
function _findQEnd(str){
  // 找第一個「？」「?」「：」「:」的位置
  for(let i=0;i<str.length;i++){
    if(str[i]==='？'||str[i]==='?'||str[i]==='：'||str[i]===':') return i;
  }
  return -1;
}

// ─────── 整理文字：去多餘空白、標點後空格 ─────────────────────────
function _tidyText(s){
  if(!s) return '';
  return cleanSpaces(
    s.replace(/\s+/g,' ')
     .replace(/([，。！？、：；,.!?:;])\s+/g,'$1')
     .trim()
  );
}

function parseQuestions(rawText){
  if(!rawText||!rawText.trim()) return [];

  // ★ 直接呼叫 preprocessQuestionText（含 OPT_SYMBOL_MAP、行首符號偵測、？/：切行等）
  let t = preprocessQuestionText(rawText);

  // 中文題號：一、二、 → 1. 2.（preprocessQuestionText 未處理）
  const ZH={'一':'1','二':'2','三':'3','四':'4','五':'5',
             '六':'6','七':'7','八':'8','九':'9','十':'10'};
  t=t.replace(/^([一二三四五六七八九十]+)[、．。.]/gm,(_,n)=>(ZH[n]||n)+'. ');

  // ── 逐行解析 ─────────────────────────────────────────────────────
  const allLines=t.split('\n').map(l=>l.trim()).filter(Boolean);
  const questions=[];
  let curQ=null, curOptKey=null, optIdx=0;
  const OPT_KEYS=['A','B','C','D','E','F','G','H'];

  function finishQ(){
    if(!curQ) return;
    curQ.stem=_tidyText(curQ.stem);
    Object.keys(curQ.options).forEach(k=>{ curQ.options[k]=_tidyText(curQ.options[k]); });
    curQ.type=Object.keys(curQ.options).length>=2?'mc':'es';
    if(curQ.stem) questions.push(curQ);
    curQ=null; curOptKey=null; optIdx=0;
  }

  function newQ(num, stemStart){
    finishQ();
    curQ={
      num, stem:stemStart, type:'es', options:{},
      answer:'', answerEs:'', keywords:[], mustKeywords:[], tags:[],
      note:'', starred:false, createdAt:Date.now(),
      reviewLevel:0, nextReview:Date.now(), lastReview:null,
      wrongCount:0, correctStreak:0, difficultyScore:5,
    };
    curOptKey=null; optIdx=0;
  }

  function addOpt(content){
    if(!curQ||!content.trim()) return;
    const key=OPT_KEYS[optIdx++]||'?';
    curQ.options[key]=content.trim();
    curOptKey=key;
  }

  function appendLine(text){
    if(!curQ||!text.trim()) return;
    if(curOptKey && curQ.options[curOptKey]!==undefined){
      // 【規則3】選項跨行：合併到當前選項
      curQ.options[curOptKey]+=' '+text;
    } else {
      // 【規則3】題幹跨行：合併到題幹
      curQ.stem+=(curQ.stem?' ':'')+text;
    }
  }

  for(const line of allLines){
    // ── 已知字母選項 §A§ §B§ ─────────────────────────────────────
    const mAlpha=line.match(/^§([A-E])§\s*(.*)/);
    if(mAlpha){
      if(!curQ) continue;
      const key=mAlpha[1];
      if(curQ.options[key]!==undefined){
        curQ.options[key]+=' '+mAlpha[2]; // 跨行追加
      } else {
        curQ.options[key]=mAlpha[2].trim();
        const ki=OPT_KEYS.indexOf(key);
        if(ki>=optIdx) optIdx=ki+1;
      }
      curOptKey=key;
      continue;
    }

    // ── §OPT§ 未命名選項 ──────────────────────────────────────────
    const mAnon=line.match(/^§OPT§\s*(.*)/);
    if(mAnon){
      if(!curQ){ continue; }
      const optContent=mAnon[1];
      addOpt(optContent);
      continue;
    }

    // ── 【規則1】行首數字 → 新題目 ───────────────────────────────
    const mNum=line.match(/^(\d{1,3})(?:[.、．）)）]\s*|\s+)([\s\S]+)/);
    // 確認是題號行：數字後面有標點分隔 OR 後面是中文長句（非量詞開頭）
    const mNumIsQ = mNum && parseInt(mNum[1])<=500 && (
      /^(\d{1,3})[.、．）)）]/.test(line) || // 標點型：1. 1、1） 絕對是題號
      (mNum[2].trim().length > 3 &&           // 空格型：後面要夠長
       !/^[年月日時分秒週天個件名條款項元萬千百公里]/.test(mNum[2].trim())) // 非量詞開頭
    );
    if(mNumIsQ){
      const num=mNum[1];
      const rest=mNum[2].trim();
      // 【規則1】找題幹結尾（？ 或 ：）
      const endIdx=_findQEnd(rest);
      const stemPart=endIdx>=0 ? rest.slice(0,endIdx+1) : rest;
      const after=endIdx>=0 ? rest.slice(endIdx+1).trim() : '';
      newQ(num, stemPart);
      // ？/：後面可能還有選項內容（同行）
      if(after) appendLine(after);
      continue;
    }

    // ── 中文題號 一、二、 ────────────────────────────────────────
    const mZh=line.match(/^([一二三四五六七八九十]+)[、．。]\s*([\s\S]+)/);
    if(mZh && ZH[mZh[1]]){
      const rest=mZh[2].trim();
      const endIdx=_findQEnd(rest);
      newQ(ZH[mZh[1]], endIdx>=0 ? rest.slice(0,endIdx+1) : rest);
      continue;
    }

    // ── 其他行：追加到選項或題幹 ────────────────────────────────
    appendLine(line);
  }

  finishQ();

  return questions.map(q=>({
    ...q,
    keywords: autoKeywords(q.stem),
    mustKeywords: [],
    searchBlob: ((q.stem||'')+' '+(autoKeywords(q.stem)||[]).join(' ')).toLowerCase(),
  }));
}

// ── 5. parseAnswerStr ────────────────────────────────────────
function parseAnswerStr(str){
  if(!str||!str.trim()) return {};
  const map={};
  for(const m of str.matchAll(/(\d{1,3})[.、\s]*([A-Ea-e])/g)){
    map[parseInt(m[1])]=m[2].toUpperCase();
  }
  return map;
}

// ── 6. parseBulkText（相容舊介面）──────────────────────────
function parseBulkText(text){
  return parseQuestions(text).map(q=>({
    ...q,
    answer:q.answer||'',
    answerEs:q.answerEs||'',
  }));
}

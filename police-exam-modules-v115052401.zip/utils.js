// ══ utils.js — 工具函式 ═════════════════════════════════════
// 全域狀態
const S = {
  page:'home', filter:'all', subF:'all', lawCat:'all',
  editId:null, editLawId:null,
  qType:'mc', correct:'A',
  quiz:{q:[],idx:0,ans:false,res:[],mode:''},
  curLaw:null, curLawName:'', lawSort:'name', bulkParsed:[], aiMd:'', aiJson:''
};

function esc(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function br(s){ return esc(s||'').split('\n').join('<br>').split('\r').join(''); }
function toast(m,d=2200){ const e=document.getElementById('toast');if(!e)return;e.textContent=m;e.classList.add('on');clearTimeout(e._t);e._t=setTimeout(()=>e.classList.remove('on'),d); }
function today(){ return new Date().toISOString().slice(0,10); }
function dl(c,fn,t='text/plain'){ const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([c],{type:t}));a.download=fn;a.click(); }
function kwArr(s){ return (s||'').split(/[,，、\s]+/).map(k=>k.trim()).filter(Boolean); }

// ── 空格清理（PDF/OCR 常見問題）──────────────────────────────
function cleanSpaces(text){
  if(!text)return text;
  let t=text;
  // 1. 不可見字元
  t=t.replace(/\u00A0/g,' ').replace(/\u200B/g,'').replace(/\uFEFF/g,'').replace(/\u3000/g,' ');
  // 2. 連續空格 → 單一
  t=t.replace(/[ \t]{2,}/g,' ');
  // 3. 中文字/標點之間的空格 → 直接合併（數字間空格保留）
  let prev='';
  while(prev!==t){
    prev=t;
    t=t.replace(/([\u4e00-\u9fff\uff00-\uffef，。！？、：；「」【】（）]) ([\u4e00-\u9fff\uff00-\uffef，。！？、：；「」【】（）])/g,'$1$2');
  }
  // 4. 中文行中換行 → 合併（非段落換行）
  t=t.replace(/([\u4e00-\u9fff，。！？、：；])\n([\u4e00-\u9fff，。！？])/g,'$1$2');
  // 5. 行尾空白
  t=t.replace(/[ \t]+$/gm,'');
  return t.trim();
}

// 關鍵字自動提取
const KW_POOL = ['比例原則','正當法律程序','臨檢','身分查證','即時強制','行政裁量',
  '警械使用','強制力','合理懷疑','現行犯','通知到場','管束','扣留',
  '警察職權','公共秩序','社會安全','行政救濟','陳述意見','書面告知',
  '告知義務','蒐集資料','偵查','搜索','扣押','逮捕','拘提',
  '通訊監察','秘密蒐證','釣魚偵查','控制下交付','陷害教唆',
  '法律保留','裁量怠惰','裁量濫用','警察補充性','緊急危難','正當防衛',
  '緊急避難','正當理由','警察勤務','勤區查察','巡邏','臨檢','守望',
  '值班','備勤','社維法','集遊法','警職法','警察法','警勤條例','警械條例'];
function autoKeywords(text){ return KW_POOL.filter(kw=>(text||'').includes(kw)); }

// 條號轉數字
const ZHN = {'零':0,'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,'百':100,'千':1000};
function zh2n(s){ let n=0,c=0;for(const ch of s){const v=ZHN[ch];if(v===undefined)continue;if(v>=10){if(c===0)c=1;n+=c*v;c=0;}else c=v;}return n+c; }
function art2n(art){ const m=art.match(/第([一二三四五六七八九十百千\d]+)條/);if(!m)return 0;const s=m[1];return /^\d+$/.test(s)?parseInt(s):zh2n(s); }

// 錯題演算法
function getWrong(qs,ats){
  const s=new Set();
  for(const q of qs){
    const qa=ats.filter(a=>a.qid===q.id&&a.correct!==null).sort((a,b)=>b.date>a.date?1:-1);
    if(!qa.length)continue;
    const r=qa.slice(0,3);
    if(r.every(a=>!a.correct)||(qa.filter(a=>!a.correct).length/qa.length>0.5&&qa.length>=2))s.add(q.id);
  }
  return s;
}

// debounce：防止高頻觸發（用於 oninput 搜尋）
function debounce(fn, delay=200){
  let timer=null;
  return function(...args){
    clearTimeout(timer);
    timer=setTimeout(()=>fn.apply(this,args), delay);
  };
}

// Confirm dialog
let _cfmCb=null;
function cfm(t,s,cb){
  _cfmCb=cb;
  document.getElementById('cfm-t').textContent=t;
  document.getElementById('cfm-s').textContent=s;
  document.getElementById('cfm-ok').onclick=()=>{closeCfm();_cfmCb?.();};
  document.getElementById('cfm-ov').classList.add('on');
}
function closeCfm(){ document.getElementById('cfm-ov').classList.remove('on'); }

const OCR_FIX = {
  '職橾':'職權','職棰':'職權','職権':'職權',
  '集會游行':'集會遊行','行政執亍':'行政執行',
  '即時強制力':'即時強制','社維法':'社會秩序維護法',
  '止當法律':'正當法律','比例庵則':'比例原則',
};

// ── 選項符號對照表（NFKC 前處理）────────────────────────────
const OPT_SYMBOL_MAP = {
  // 圓圈數字 → 直接對應 A B C D E
  '①':'A','②':'B','③':'C','④':'D','⑤':'E',
  '❶':'A','❷':'B','❸':'C','❹':'D','❺':'E',
  '⑴':'A','⑵':'B','⑶':'C','⑷':'D','⑸':'E',
  'ㄅ':'A','ㄆ':'B','ㄇ':'C','ㄈ':'D',
  // 方塊/圓形符號 → 無名選項分隔 §OPT§
  '☒':'§OPT§','☐':'§OPT§','□':'§OPT§','■':'§OPT§',
  '▢':'§OPT§','◯':'§OPT§','○':'§OPT§','●':'§OPT§',
  '◉':'§OPT§','◎':'§OPT§','▪':'§OPT§','▫':'§OPT§',
  '◆':'§OPT§','◇':'§OPT§','▶':'§OPT§','▷':'§OPT§',
  '►':'§OPT§','▸':'§OPT§','‣':'§OPT§',
  // 幾何圖形區塊補充（U+25A3~U+25FF，PDF常見）
  '▣':'§OPT§','▤':'§OPT§','▥':'§OPT§','▦':'§OPT§','▧':'§OPT§','▨':'§OPT§','▩':'§OPT§',
  '▬':'§OPT§','▭':'§OPT§','▮':'§OPT§','▯':'§OPT§','▰':'§OPT§','▱':'§OPT§',
  '◈':'§OPT§','◊':'§OPT§','◌':'§OPT§','◍':'§OPT§','◐':'§OPT§','◑':'§OPT§',
  '◒':'§OPT§','◓':'§OPT§','◔':'§OPT§','◕':'§OPT§','◖':'§OPT§','◗':'§OPT§',
  '◼':'§OPT§','◻':'§OPT§','◾':'§OPT§','◽':'§OPT§',
  // Dingbats / Misc Symbols
  '✦':'§OPT§','✧':'§OPT§','✪':'§OPT§','✫':'§OPT§','✬':'§OPT§','✭':'§OPT§',
  '❑':'§OPT§','❒':'§OPT§','❏':'§OPT§',
};

// ── 1. preprocessQuestionText ───────────────────────────────
function preprocessQuestionText(text){
  if(!text) return '';
  let t = text;

  // OCR 錯字修正
  Object.entries(OCR_FIX).forEach(([wrong,right])=>{ t=t.split(wrong).join(right); });

  // 選項符號替換（必須在 NFKC 前，否則 ①→1）
  Object.entries(OPT_SYMBOL_MAP).forEach(([sym,val])=>{
    if(val==='§OPT§'){
      t=t.split(sym).join('§OPT§');
    } else {
      t=t.split(sym).join('§'+val+'§');
    }
  });

  // 「行首未知符號偵測」：任何非字母/數字/中文的符號，
  // 只要重複出現在 2 行以上的行首，就視為選項分隔符號
  {
    const lineArr=t.split('\n');
    const lineStartMap={};
    lineArr.forEach(line=>{
      const trimmed=line.trim();
      if(!trimmed)return;
      const ch=trimmed[0];
      const cp=ch.codePointAt(0);
      // 排除：字母、數字、中文、常見標點、已知選項標記
      const isWordOrPunct=
        (cp>=0x41&&cp<=0x7A)||(cp>=0x61&&cp<=0x7A)||  // A-Z a-z
        (cp>=0x30&&cp<=0x39)||                          // 0-9
        (cp>=0x4E00&&cp<=0x9FFF)||                      // 中文
        (cp>=0xFF01&&cp<=0xFF60)||                      // 全形字母數字
        '（(）)【】「」『』。，、；：！？…—'.includes(ch)||
        ch==='§';  // 已轉換的標記
      if(!isWordOrPunct){
        lineStartMap[ch]=(lineStartMap[ch]||0)+1;
      }
    });
    // 找出現 2 次以上且不是已知選項標記 §A§ 的符號
    const detected=Object.entries(lineStartMap)
      .filter(([ch,n])=>n>=1&&!ch.match(/^[①②③④⑤❶❷❸❹]$/))
      .sort((a,b)=>b[1]-a[1]);
    if(detected.length>0){
      detected.forEach(([sep])=>{
        // 行首符號替換為 §OPT§
        // 同時處理行中出現的同一符號（如「▩甲 ▩乙 ▩丙」在同一行）
        const escapedSep=sep.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
        t=t.split('\n').map(line=>{
          const trimmed=line.trim();
          if(!trimmed) return line;
          if(trimmed.startsWith(sep)){
            // 行首有符號：整行替換（含行中的同一符號）
            const replaced=trimmed.slice(sep.length).trim()
              .replace(new RegExp('\\s*'+escapedSep+'\\s*','g'),'\n§OPT§ ');
            return '\n§OPT§ '+replaced;
          }
          // 行中有符號但行首沒有：也切開
          if(trimmed.includes(sep)){
            return '\n'+trimmed.replace(new RegExp('\\s*'+escapedSep+'\\s*','g'),'\n§OPT§ ');
          }
          return line;
        }).join('\n');
      });
    }
    // 同時保留 Private Use Area 偵測（PDF 私有字元）
    const pvtMap2={};
    for(const ch of t){
      const cp=ch.codePointAt(0);
      if(cp>=0xE000&&cp<=0xF8FF) pvtMap2[ch]=(pvtMap2[ch]||0)+1;
    }
    const pvtSep2=Object.entries(pvtMap2).filter(([,n])=>n>=2).sort((a,b)=>b[1]-a[1])[0];
    if(pvtSep2) t=t.split(pvtSep2[0]).join('§OPT§');
  }

  // NFKC 正規化（全形→半形）
  t=t.normalize('NFKC');

  // 換行統一
  t=t.replace(/\r\n/g,'\n').replace(/\r/g,'\n');

  // ★ 全行格式：在選項和題號前插入換行
  // 讓「...委員會 (B)...」→「...委員會\n(B)...」
  // 讓「...委員會 2. 下一題」→「...委員會\n2. 下一題」
  t=t.replace(/([^(\n])\s*\(([A-Ea-e])\)/g,'$1\n($2)');
  t=t.replace(/([\u4e00-\u9fff\uff00-\uffef\u3000-\u303f）)\]】」])\s*(\d{1,3}[.、．]\s)/g,'$1\n$2');

  // 不可見字元清除
  t=t.replace(/[\u00A0\u200B\u200C\u200D\uFEFF]/g,'').replace(/\u3000/g,' ');

  // 全形括號選項：（A）(A) → §A§
  t=t.replace(/[（(]\s*([A-Ea-e])\s*[）)]/g,(_,k)=>'§'+k.toUpperCase()+'§');
  // 數字括號選項：(1)(2)(3)(4) → §A§§B§§C§§D§
  // 只在沒有字母選項(A)(B)(C)(D)的情況下才啟用（有字母選項時 (1) 是題號）
  if(!/[（(][A-Ea-e][）)]/.test(t) && !/[§][A-E][§]/.test(t)){
    t=t.replace(/(?:^|(?<=\n))[（(]([1-4１-４])[）)]\s*/gm,(_,n)=>{
      const MAP={'1':'A','2':'B','3':'C','4':'D','１':'A','２':'B','３':'C','４':'D'};
      return '\n§'+(MAP[n]||n)+'§ ';
    });
  }

  // 讓選項各自換行（§OPT§ 和 §A§ 前後加換行）
  t=t.replace(/([^\n])§OPT§/g,'$1\n§OPT§');
  t=t.replace(/([^\n])§([A-E])§/g,'$1\n§$2§');
  t=t.replace(/§([A-E])§\s*/g,'\n§$1§ ');
  t=t.replace(/§OPT§\s*/g,'\n§OPT§ ');

  // 中文字間多餘空格（保留數字前後）
  let prev='';
  let _wLim1=0;
  while(prev!==t&&_wLim1++<8){
    prev=t;
    t=t.replace(/([\u4e00-\u9fff，。！？、：；]) ([\u4e00-\u9fff，。！？、：；])/g,'$1$2');
  }

  // 行尾空白
  t=t.replace(/[ \t]+$/gm,'');

  return t.trim();
}

// ── 2. normalizeOptions ─────────────────────────────────────
// ── 3. parseQuestions 主解析函式 ───────────────────────────
